import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { createContactSubmission, getAllContactSubmissions } from "./db";
import { notifyOwner } from "./_core/notification";

export const appRouter = router({
  // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  contact: router({
    submit: publicProcedure
      .input(
        z.object({
          name: z.string().min(1, 'Name is required'),
          position: z.string().optional(),
          company: z.string().optional(),
          category: z.enum(['government', 'talent', 'ai', 'other']),
          challenge: z.string().optional(),
          email: z.string().email('Invalid email').optional(),
          phone: z.string().optional(),
          language: z.enum(['en', 'zh', 'tc']).default('zh'),
        })
      )
      .mutation(async ({ input }) => {
        try {
          const submission = await createContactSubmission({
            name: input.name,
            position: input.position || null,
            company: input.company || null,
            category: input.category,
            challenge: input.challenge || null,
            email: input.email || null,
            phone: input.phone || null,
            language: input.language,
            status: 'new',
          });

          // Notify owner about new submission
          if (submission) {
            await notifyOwner({
              title: 'New Contact Form Submission',
              content: `New inquiry from ${input.name} (${input.category}). Email: ${input.email || 'Not provided'}`,
            }).catch(err => console.error('[Notification] Failed to notify owner:', err));
          }

          return {
            success: true,
            id: submission?.id,
          };
        } catch (error) {
          console.error('[API] Failed to submit contact form:', error);
          throw error;
        }
      }),
    list: publicProcedure.query(async () => {
      return await getAllContactSubmissions();
    }),
  }),
});

export type AppRouter = typeof appRouter;
