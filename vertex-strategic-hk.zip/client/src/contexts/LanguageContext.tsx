import { createContext, useContext, ReactNode } from 'react';

type Language = 'en' | 'zh' | 'tc';

interface Translations {
  [key: string]: {
    en: string;
    zh: string;
    tc: string;
  };
}

const translations: Translations = {
  // About Us
  'about.title': { en: 'About InsightfulVision Consulting', zh: '关于通微达观', tc: '關於通微達觀' },
  'about.para1': { 
    en: 'InsightfulVision Consulting Limited was founded by a group of elite partners from top-tier international strategy consulting, management consulting, and risk consulting firms. Our founding team brings decades of combined experience in advising global enterprises and government institutions.',
    zh: '通微达观咨询有限公司由一群来自国际顶尖战略咨询、管理咨询及风险咨询公司的资深合伙人共同创立。我们不仅拥有一支具备数十年复合经验的创新团队，更长期致力于为全球领先企业与政府机构提供高标准的顾问服务。',
    tc: '通微達觀諮詢有限公司由一群來自國際頂尖戰略諮詢、管理諮詢及風險諮詢公司的資深合伙人共同創立。我們不僅擁有一支具備數十年複合經驗的創新團隊，更長期致力於為全球領先企業與政府機構提供高標準的顧問服務。'
  },
  'about.para2': { 
    en: 'We specialize in helping mainland enterprises enter Hong Kong and expand globally, assisting Hong Kong government agencies and public sector organizations in understanding the mainland and international markets, and equipping them with world-class expert resources. Our mission is to bridge strategic gaps and accelerate growth across borders.',
    zh: '我们专注于协助内地企业植根香港并进军全球，同时为香港政府机构及公营部门提供深度的内地与海外市场洞察，并配置世界级的专家资源。我们的使命是弥合战略差距，加速跨境增长。',
    tc: '我們專注於協助內地企業植根香港並進軍全球，同時為香港政府機構及公營部門提供深度的內地與海外市場洞察，並配置世界級的專家資源。我們的使命是彌合戰略差距，加速跨境增長。'
  },
  'about.para3': { 
    en: 'Understanding the flexibility required by our clients, we leverage AI-powered solutions to address diverse business needs. Whether through fractional leadership, strategic advisory, or intelligent business matching, IVCHK delivers tailored, data-driven consulting that transforms challenges into opportunities.',
    zh: '依托对客户需求的精准理解，我们通过 AI 赋能的解决方案应对复杂多变的业务挑战。无论是 Fractional（按需）领导力、战略咨询还是智能化业务匹配，通微达观均能提供量身定制、数据驱动的专业服务，助力客户将挑战转化为确定性的机遇。',
    tc: '依託對客戶需求的精準理解，我們通過 AI 賦能的解決方案應對複雜多變的業務挑戰。無論是 Fractional（按需）領導力、戰略諮詢還是智能化業務匹配，通微達觀均能提供量身定制、數據驱動的專業服務，助力客戶將挑戰轉化為確定性的機遇。'
  },
  'about.value1.icon': { en: '\ud83c\udf1f', zh: '\ud83c\udf1f', tc: '\ud83c\udf1f' },
  'about.value1.title': { en: 'Elite Expertise', zh: '精英专业', tc: '精英專業' },
  'about.value1.desc': { en: 'Decades of combined experience from top consulting firms', zh: '来自顶尖咨询公司的数十年联合经验', tc: '來自頂尖諮詢公司的數十年联合經驗' },
  'about.value2.icon': { en: '\ud83c\udf10', zh: '\ud83c\udf10', tc: '\ud83c\udf10' },
  'about.value2.title': { en: 'Cross-Border Excellence', zh: '跨境卓越', tc: '跨境卓越' },
  'about.value2.desc': { en: 'Proven track record in Greater China and global markets', zh: '在大中华区和全球市场的成紧轨迹', tc: '在大中華區和全球市場的成紧軌跡' },
  'about.value3.icon': { en: '\ud83e\udd16', zh: '\ud83e\udd16', tc: '\ud83e\udd16' },
  'about.value3.title': { en: 'AI-Powered Innovation', zh: 'AI 驱动的创新', tc: 'AI 驅動的創新' },
  'about.value3.desc': { en: 'Data-driven solutions for modern business challenges', zh: '面向现代业务挑战的数据驱动解决方案', tc: '面向現代業務挑戰的數據驱動解決方案' },

  // Navigation
  'nav.about': { en: 'About Us', zh: '公司简介', tc: '公司簡介' },
  'nav.services': { en: 'Services', zh: '核心服务', tc: '核心服務' },
  'nav.experts': { en: 'Expert Matrix', zh: '专家矩阵', tc: '專家矩陣' },
  'nav.insights': { en: 'Industry Insights', zh: '行业洞察', tc: '行業洞察' },
  'nav.partners': { en: 'Partners', zh: '合作伙伴', tc: '合作夥伴' },
  'nav.contact': { en: 'Contact', zh: '联系我们', tc: '聯繫我們' },
  'nav.language': { en: 'EN / 中 / 繁', zh: '英 / 中 / 繁', tc: '英 / 中 / 繁' },

  // Hero Section
  'hero.title': { 
    en: 'Bridging Global Talent\nEmpowering HK Innovation',
    zh: '链接全球顶尖智力\n赋能香港科创未来',
    tc: '鏈接全球頂尖智力\n賦能香港科創未來'
  },
  'hero.subtitle': { 
    en: 'Focused on government affairs coordination, strategic expansion, and premium flexible workforce solutions.\nLeveraging AI matching technology to provide plug-and-play expert resources for public institutions and leading enterprises.',
    zh: '专注于政府事务协调、战略性扩张及高端灵活用工解决方案。\n依托 AI 匹配技术，为公营机构与领军企业提供即插即用的专家大脑。',
    tc: '專注於政府事務協調、戰略性擴張及高端靈活用工解決方案。\n依託 AI 匹配技術，為公營機構與領軍企業提供即插即用的專家大腦。'
  },
  'hero.cta1': { en: 'Book Consultation', zh: '预约初步咨询', tc: '預約初步諮詢' },
  'hero.cta2': { en: 'Explore Expert Pool', zh: '了解专家池', tc: '了解專家池' },

  // Service Pillars - 2+1 Layout
  'services.title': { en: 'Our Strategic Services', zh: '我们的战略服务', tc: '我們的戰略服務' },
  'services.subtitle': { 
    en: 'A 2+1 integrated approach: two flagship services powered by our proprietary AI engine.',
    zh: '"2+1"战略布局：两项核心服务由我们自主研发的 AI 匹配引擎驱动。',
    tc: '"2+1"戰略佈局：兩項核心服務由我們自主研發的 AI 匹配引擎驅動。'
  },
  'services.service1.title': { en: 'Cross-Border Strategy & Public-Private Engagement', zh: '跨境战略与政企事务', tc: '跨境戰略與政企事務' },
  'services.service1.desc': { 
    en: 'Serving as a strategic hub connecting Greater China with global markets, we provide comprehensive navigation for Chinese firms going global, Hong Kong firms heading north, and multinationals entering the region. With deep insight into both public policy and private sector dynamics, IVCHK assists clients in optimizing public-private engagement, deciphering regulatory trends, and providing hands-on guidance from market entry to localized operations.',
    zh: '作为连接大中华区与全球市场的战略枢纽，我们为中企出海、港企北上及外企入港提供全方位的导航。凭借对公共政策与私营部门逻辑的双重洞察，IVCHK 协助客户优化政企沟通、解读监管趋势，并提供从合规准入到属地化经营的实战指导。',
    tc: '作為連接大中華區與全球市場的戰略樞紐，我們為中企出海、港企北上及外企入港提供全方位的導航。憑藉對公共政策與私營部門邏輯的雙重洞察，IVCHK 協助客戶優化政企溝通、解讀監管趨勢，並提供從合規準入到屬地化經營的實戰指導。'
  },
  'services.service2.title': { en: 'Premium Fractional Leadership', zh: '高端 Fractional 领导力外包', tc: '高端 Fractional 領導力外包' },
  'services.service2.desc': { 
    en: 'Providing flexible C-Suite leadership support for high-growth tech firms or traditional enterprises in transition. IVCHK\'s senior advisors embed as Fractional Executives, offering expert guidance in market expansion, brand strategy, and international operations—enabling firms to access world-class strategic vision and industry networks without the burden of full-time executive costs.',
    zh: '为处于关键增长期的技术公司或转型中的传统企业提供灵活的 C-Suite 领导力支持。我们的资深顾问以"非全职高管"身份深度嵌入企业，提供市场拓展、品牌战略及国际化运营的专业指导，帮助企业在无需承担全职高管昂贵成本的情况下，获取世界级的战略眼光与行业资源。',
    tc: '為處於關鍵增長期的技術公司或轉型中的傳統企業提供靈活的 C-Suite 領導力支持。我們的資深顧問以"非全職高管"身份深度嵌入企業，提供市場拓展、品牌戰略及國際化運營的專業指導，幫助企業在無需承擔全職高管昂貴成本的情況下，獲取世界級的戰略眼光與行業資源。'
  },
  'services.service3.title': { en: 'AI-Powered Matching Engine', zh: 'AI 驱动的业务匹配引擎', tc: 'AI 驅動的業務匹配引擎' },
  'services.service3.desc': { 
    en: '[Core Enablement] All IVCHK consulting services are powered by our proprietary AI Matching Engine. Utilizing advanced algorithms and a global expert database, this engine provides precision B2B and talent-search support—evolving traditional "experience-led" consulting into "data-driven" insights, significantly enhancing decision-making efficiency.',
    zh: '【核心赋能】IVCHK 的所有咨询服务均由我们自主研发的 AI 匹配引擎驱动。利用先进的算法与全球专家数据库，该引擎为我们的核心业务提供精准的商业对接与人才搜索支持，将传统的"经验驱动"升级为"数据驱动"，显著提升决策效率。',
    tc: '【核心賦能】IVCHK 的所有諮詢服務均由我們自主研發的 AI 匹配引擎驅動。利用先進的算法與全球專家數據庫，該引擎為我們的核心業務提供精準的商業對接與人才搜索支持，將傳統的"經驗驅動"升級為"數據驅動"，顯著提升決策效率。'
  },
  'services.learnMore': { en: 'Learn More', zh: '了解更多', tc: '了解更多' },

  // Expert Matrix
  'experts.title': { en: 'Expert Matrix: Core Competencies', zh: '专家矩阵：核心竞争力', tc: '專家矩陣：核心競爭力' },
  'experts.subtitle': { 
    en: 'Our team brings together elite experts from leading global enterprises and institutions to provide professional consulting services.',
    zh: '我们的团队汇聚了来自全球顶级企业和机构的精英专家，为您提供最专业的咨询服务。',
    tc: '我們的團隊匯聚了來自全球頂級企業和機構的精英專家，為您提供最專業的諮詢服務。'
  },
  'experts.cta': { en: 'Contact Us', zh: '联系我们', tc: '聯繫我們' },

  // Expert Profiles
  'expert.1.name': { en: 'Mr. Li', zh: '李先生', tc: '李先生' },
  'expert.1.title': { en: 'Strategy Advisor', zh: '战略顾问', tc: '戰略顧問' },
  'expert.1.background': { en: 'Former Partner at International Top-Tier Strategy Consulting Firm', zh: '前国际顶尖战略咨询公司合伙人', tc: '前國際頂尖戰略諮詢公司合夥人' },
  'expert.1.expertise': { en: 'Government Affairs, Strategic Planning, Organizational Change', zh: '政府事务、战略规划、组织变革', tc: '政府事務、戰略規劃、組織變革' },

  'expert.2.name': { en: 'Ms. Wang', zh: '王女士', tc: '王女士' },
  'expert.2.title': { en: 'Tech Leader', zh: '科技领导者', tc: '科技領導者' },
  'expert.2.background': { en: 'PhD in Advanced Technology from Global Leading Research Institution', zh: '全球顶尖科研机构高级技术博士', tc: '全球頂尖科研機構高級技術博士' },
  'expert.2.expertise': { en: 'AI Technology, Innovation Management, Commercialization', zh: 'AI 技术、创新管理、商业化落地', tc: 'AI 技術、創新管理、商業化落地' },

  'expert.3.name': { en: 'Mr. Chen', zh: '陈先生', tc: '陳先生' },
  'expert.3.title': { en: 'Policy Expert', zh: '政策专家', tc: '政策專家' },
  'expert.3.background': { en: 'Senior Government Affairs Specialist with Extensive Hong Kong Experience', zh: '资深政府事务专家', tc: '資深政府事務專家' },
  'expert.3.expertise': { en: 'Policy Analysis, Compliance Review, Affairs Coordination', zh: '政策分析、合规审查、事务协调', tc: '政策分析、合規審查、事務協調' },

  'expert.4.name': { en: 'Ms. Zhang', zh: '张女士', tc: '張女士' },
  'expert.4.title': { en: 'Operations Director', zh: '运营总监', tc: '運營總監' },
  'expert.4.background': { en: 'Senior Member of International Business Community', zh: '国际商业社群资深成员', tc: '國際商業社群資深成員' },
  'expert.4.expertise': { en: 'Operations Management, International Cooperation, Ecosystem Building', zh: '运营管理、国际合作、生态建设', tc: '運營管理、國際合作、生態建設' },

  'expert.5.name': { en: 'Mr. Zhou', zh: '周先生', tc: '周先生' },
  'expert.5.title': { en: 'Finance Director', zh: '财务总监', tc: '財務總監' },
  'expert.5.background': { en: 'Former CFO at Global Fortune 500 Company', zh: '全球财富 500 强公司前首席财务官', tc: '全球財富 500 強公司前首席財務官' },
  'expert.5.expertise': { en: 'Financial Strategy, Capital Operations, Risk Management', zh: '财务战略、资本运作、风险管理', tc: '財務戰略、資本運作、風險管理' },

  'expert.6.name': { en: 'Ms. Liu', zh: '刘女士', tc: '劉女士' },
  'expert.6.title': { en: 'Market Strategy Lead', zh: '市场战略主管', tc: '市場戰略主管' },
  'expert.6.background': { en: 'Senior Executive from International Management Consulting Firm', zh: '国际管理咨询公司资深高管', tc: '國際管理諮詢公司資深高管' },
  'expert.6.expertise': { en: 'Market Entry, Brand Strategy, Competitive Analysis', zh: '市场进入、品牌战略、竞争分析', tc: '市場進入、品牌戰略、競爭分析' },

  'expert.7.name': { en: 'Mr. Huang', zh: '黄先生', tc: '黃先生' },
  'expert.7.title': { en: 'Risk Management Expert', zh: '风险管理专家', tc: '風險管理專家' },
  'expert.7.background': { en: 'Former Risk Officer at International Financial Institution', zh: '国际金融机构前风险官', tc: '國際金融機構前風險官' },
  'expert.7.expertise': { en: 'Compliance, Regulatory Strategy, Risk Assessment', zh: '合规、监管战略、风险评估', tc: '合規、監管戰略、風險評估' },

  'expert.8.name': { en: 'Ms. Xu', zh: '徐女士', tc: '徐女士' },
  'expert.8.title': { en: 'Innovation Director', zh: '创新总监', tc: '創新總監' },
  'expert.8.background': { en: 'PhD in Innovation Management from Top Global University', zh: '全球顶尖大学创新管理博士', tc: '全球頂尖大學創新管理博士' },
  'expert.8.expertise': { en: 'Digital Transformation, Innovation Strategy, Technology Integration', zh: '数字转型、创新战略、技术融合', tc: '數字轉型、創新戰略、技術融合' },

  'expert.9.name': { en: 'Mr. Guo', zh: '郭先生', tc: '郭先生' },
  'expert.9.title': { en: 'International Relations Specialist', zh: '国际关系专家', tc: '國際關係專家' },
  'expert.9.background': { en: 'Former Diplomat with 20+ Years International Experience', zh: '资深外交官，20 年以上国际工作经验', tc: '資深外交官，20 年以上國際工作經驗' },
  'expert.9.expertise': { en: 'Diplomatic Relations, International Cooperation, Cross-Border Strategy', zh: '外交关系、国际合作、跨境战略', tc: '外交關係、國際合作、跨境戰略' },

  'expert.10.name': { en: 'Ms. Shen', zh: '沈女士', tc: '沈女士' },
  'expert.10.title': { en: 'Supply Chain Expert', zh: '供应链专家', tc: '供應鏈專家' },
  'expert.10.background': { en: 'Senior Supply Chain Director from Global Manufacturing Leader', zh: '全球制造业领导者资深供应链总监', tc: '全球製造業領導者資深供應鏈總監' },
  'expert.10.expertise': { en: 'Supply Chain Optimization, Logistics Strategy, Cost Management', zh: '供应链优化、物流战略、成本管理', tc: '供應鏈優化、物流戰略、成本管理' },

  'expert.11.name': { en: 'Mr. Wu', zh: '吴先生', tc: '吳先生' },
  'expert.11.title': { en: 'HR Strategy Lead', zh: '人力资源战略主管', tc: '人力資源戰略主管' },
  'expert.11.background': { en: 'Chief HR Officer from International Tech Company', zh: '国际科技公司首席人力资源官', tc: '國際科技公司首席人力資源官' },
  'expert.11.expertise': { en: 'Talent Strategy, Organizational Development, Change Management', zh: '人才战略、组织发展、变革管理', tc: '人才戰略、組織發展、變革管理' },

  'expert.12.name': { en: 'Ms. Qian', zh: '钱女士', tc: '錢女士' },
  'expert.12.title': { en: 'Sustainability Officer', zh: '可持续发展官', tc: '可持續發展官' },
  'expert.12.background': { en: 'Environmental Strategy Expert from Global Sustainability Leader', zh: '全球可持续发展领导者环境战略专家', tc: '全球可持續發展領導者環境戰略專家' },
  'expert.12.expertise': { en: 'ESG Strategy, Carbon Management, Sustainability Reporting', zh: 'ESG 战略、碳管理、可持续发展报告', tc: 'ESG 戰略、碳管理、可持續發展報告' },

  'expert.13.name': { en: 'Mr. Sun', zh: '孙先生', tc: '孫先生' },
  'expert.13.title': { en: 'Legal & Compliance Director', zh: '法务与合规总监', tc: '法務與合規總監' },
  'expert.13.background': { en: 'Senior Legal Counsel from International Law Firm', zh: '国际律师事务所资深法律顾问', tc: '國際律師事務所資深法律顧問' },
  'expert.13.expertise': { en: 'Corporate Law, Regulatory Compliance, Contract Management', zh: '公司法、监管合规、合同管理', tc: '公司法、監管合規、合同管理' },

  'expert.14.name': { en: 'Ms. Zhu', zh: '朱女士', tc: '朱女士' },
  'expert.14.title': { en: 'Data Analytics Lead', zh: '数据分析主管', tc: '數據分析主管' },
  'expert.14.background': { en: 'Data Science Director from Global Tech Giant', zh: '全球科技巨头数据科学总监', tc: '全球科技巨頭數據科學總監' },
  'expert.14.expertise': { en: 'Data Strategy, Business Intelligence, Analytics Framework', zh: '数据战略、商业智能、分析框架', tc: '數據戰略、商業智能、分析框架' },

  'expert.15.name': { en: 'Mr. Lin', zh: '林先生', tc: '林先生' },
  'expert.15.title': { en: 'Manufacturing Expert', zh: '制造业专家', tc: '製造業專家' },
  'expert.15.background': { en: 'Former COO of Leading Manufacturing Enterprise', zh: '领先制造企业前首席运营官', tc: '領先製造企業前首席運營官' },
  'expert.15.expertise': { en: 'Operations Excellence, Lean Management, Quality Control', zh: '运营卓越、精益管理、质量控制', tc: '運營卓越、精益管理、質量控制' },

  'expert.16.name': { en: 'Ms. He', zh: '何女士', tc: '何女士' },
  'expert.16.title': { en: 'Customer Experience Expert', zh: '客户体验专家', tc: '客戶體驗專家' },
  'expert.16.background': { en: 'Chief Customer Officer from Global Consumer Brand', zh: '全球消费品牌首席客户官', tc: '全球消費品牌首席客戶官' },
  'expert.16.expertise': { en: 'Customer Strategy, Experience Design, Loyalty Programs', zh: '客户战略、体验设计、忠诚度计划', tc: '客戶戰略、體驗設計、忠誠度計劃' },

  'expert.17.name': { en: 'Mr. Cao', zh: '曹先生', tc: '曹先生' },
  'expert.17.title': { en: 'Real Estate Developer', zh: '房地产开发专家', tc: '房地產開發專家' },
  'expert.17.background': { en: 'Senior Development Executive from International Real Estate Group', zh: '国际房地产集团资深开发高管', tc: '國際房地產集團資深開發高管' },
  'expert.17.expertise': { en: 'Project Development, Urban Planning, Investment Analysis', zh: '项目开发、城市规划、投资分析', tc: '項目開發、城市規劃、投資分析' },

  'expert.18.name': { en: 'Ms. Jiang', zh: '江女士', tc: '江女士' },
  'expert.18.title': { en: 'Healthcare Industry Expert', zh: '医疗健康专家', tc: '醫療健康專家' },
  'expert.18.background': { en: 'Chief Medical Officer from Leading Healthcare Organization', zh: '领先医疗机构首席医疗官', tc: '領先醫療機構首席醫療官' },
  'expert.18.expertise': { en: 'Healthcare Strategy, Regulatory Affairs, Clinical Operations', zh: '医疗战略、监管事务、临床运营', tc: '醫療戰略、監管事務、臨床運營' },

  'expert.19.name': { en: 'Mr. Luo', zh: '罗先生', tc: '羅先生' },
  'expert.19.title': { en: 'Energy Transition Expert', zh: '能源转型专家', tc: '能源轉型專家' },
  'expert.19.background': { en: 'Senior Energy Strategy Officer from Global Energy Company', zh: '全球能源公司资深能源战略官', tc: '全球能源公司資深能源戰略官' },
  'expert.19.expertise': { en: 'Energy Strategy, Renewable Transition, Carbon Neutrality', zh: '能源战略、可再生能源转型、碳中和', tc: '能源戰略、可再生能源轉型、碳中和' },

  'expert.20.name': { en: 'Ms. Deng', zh: '邓女士', tc: '鄧女士' },
  'expert.20.title': { en: 'Education & Training Director', zh: '教育与培训总监', tc: '教育與培訓總監' },
  'expert.20.background': { en: 'Head of Corporate University from International Enterprise', zh: '国际企业企业大学负责人', tc: '國際企業企業大學負責人' },
  'expert.20.expertise': { en: 'Talent Development, Learning Strategy, Capability Building', zh: '人才发展、学习战略、能力建设', tc: '人才發展、學習戰略、能力建設' },

  // Served Clients
  'partners.title': { en: 'Served Clients', zh: '既往服务客户', tc: '既往服務客戶' },
  'partners.subtitle': { 
    en: 'We have partnered with leading organizations across government, state enterprises, and multinational corporations.',
    zh: '我们与政府部门、国企集团及跨国企业等领先机构建立了深度合作关系。',
    tc: '我們與政府部門、國企集團及跨國企業等領先機構建立了深度合作關係。'
  },
  'partners.description': { 
    en: 'Our clients include multiple Hong Kong government departments, major state-owned enterprises, provincial SOEs, multinational corporations, and international technology firms.',
    zh: '我们的客户包括香港多个政府部门、大型央企集团、省级国企、跨国企业及国际科技公司。',
    tc: '我們的客戶包括香港多個政府部門、大型央企集團、省級國企、跨國企業及國際科技公司。'
  },
  'client.1.name': { en: 'Multiple Hong Kong Government Departments', zh: '香港多个政府部门', tc: '香港多個政府部門' },
  'client.2.name': { en: 'Major State-Owned Enterprise Hong Kong Operations', zh: '某综合性央企香港公司', tc: '某綜合性央企香港公司' },
  'client.3.name': { en: 'Provincial State-Owned Enterprise Hong Kong Division', zh: '广东省某省级国企在港业务', tc: '廣東省某省級國企在港業務' },
  'client.4.name': { en: 'Major Central Enterprise International Operations', zh: '某大型央企在港国际板块', tc: '某大型央企在港國際板塊' },
  'client.5.name': { en: 'French Telecommunications Enterprise China Headquarters', zh: '某法国电信企业中国区总部', tc: '某法國電信企業中國區總部' },
  'clients.note': { en: 'These clients include teams that our founding members served at their previous organization.', zh: '这些客户包括创始团队在前一个公司服务的团队。', tc: '這些客戶包括創始團隊在前一個公司服務的團隊。' },

  // Contact Form
  'contact.title': { en: 'Start Your Excellence Journey', zh: '开启您的卓越增长', tc: '開啟您的卓越增長' },
  'contact.subtitle': { 
    en: 'Tell us about your challenges and aspirations. Let\'s explore how IVCHK can drive your strategic growth.',
    zh: '告诉我们您的挑战和愿景。让我们一起探索 IVCHK 如何助力您的战略增长。',
    tc: '告訴我們您的挑戰和願景。讓我們一起探索 IVCHK 如何助力您的戰略增長。'
  },
  'contact.name': { en: 'Your Name', zh: '您的姓名', tc: '您的姓名' },
  'contact.position': { en: 'Position', zh: '职位', tc: '職位' },
  'contact.company': { en: 'Company / Institution', zh: '公司/机构名称', tc: '公司/機構名稱' },
  'contact.category': { en: 'Inquiry Category', zh: '需求类别', tc: '需求類別' },
  'contact.challenge': { en: 'Describe Your Challenge', zh: '简短描述您的挑战', tc: '簡短描述您的挑戰' },
  'contact.phone': { en: 'Phone (Optional)', zh: '电话（可选）', tc: '電話（可選）' },
  'contact.submit': { en: 'Submit Inquiry', zh: '提交咨询', tc: '提交諮詢' },
  'contact.success': { en: 'Thank You!', zh: '感谢您的咨询！', tc: '感謝您的諮詢！' },
  'contact.successMsg': { 
    en: 'We have received your inquiry and will contact you within 2 business days.',
    zh: '我们已收到您的咨询，将在 2 个工作日内与您联系。',
    tc: '我們已收到您的諮詢，將在 2 個工作日內與您聯繫。'
  },
  'contact.successNote': { 
    en: 'A confirmation notification has been sent to our team.',
    zh: '确认通知已发送至我们的团队。',
    tc: '確認通知已發送至我們的團隊。'
  },

  // Footer
  'footer.company': { en: 'InsightfulVision Consulting Limited', zh: '通微达观咨询有限公司', tc: '通微達觀諮詢有限公司' },
  'footer.email': { en: 'Email: contact@ivchk.com', zh: '邮箱：contact@ivchk.com', tc: '郵箱：contact@ivchk.com' },
  'footer.copyright': { 
    en: '© 2026 InsightfulVision Consulting Limited. All Rights Reserved.',
    zh: '© 2026 通微达观咨询有限公司。保留所有权利。',
    tc: '© 2026 通微達觀諮詢有限公司。保留所有權利。'
  },
  'footer.quickLinks': { en: 'Quick Links', zh: '快速链接', tc: '快速鏈接' },
  'footer.services': { en: 'Services', zh: '核心服务', tc: '核心服務' },
  'footer.about': { en: 'Elite consulting partner connecting Greater China with global markets.', zh: '精英咨询伙伴，连接大中华区与全球市场。', tc: '精英諮詢夥伴，連接大中華區與全球市場。' },
  'footer.contact': { en: 'Contact', zh: '联系方式', tc: '聯絡方式' },
  'footer.phone': { en: '', zh: '', tc: '' },

  // Comparison Table
  'comparison.title': { en: 'Why Choose IVC?', zh: '为什么选择通微达观？', tc: '為什麼選擇通微達觀？' },
  'comparison.subtitle': { en: 'IVC stands apart from headhunting companies and expert networks through deep engagement, AI-driven precision, and measurable business outcomes.', zh: 'IVC 通过深度参与、AI 驱动的精准匹配和可衡量的业务成果，与猎头公司和专家访谈公司形成鲜明对比。', tc: 'IVC 通過深度參與、AI 驱動的精準匹配和可衡量的業務成果，與獵頭公司和專家訪談公司形成鮮明對比。' },
  'comparison.dimension': { en: 'Dimension', zh: '比较维度', tc: '比較維度' },
  'comparison.ivc': { en: 'IVC (Fractional Leadership & Public-Private Hub)', zh: 'IVC（Fractional 领导力 & 政企枢纽）', tc: 'IVC（Fractional 領導力 & 政企樞紐）' },
  'comparison.headhunter': { en: 'Headhunting Company', zh: '猎头公司', tc: '獵頭公司' },
  'comparison.expertNetwork': { en: 'Expert Network', zh: '专家访谈公司', tc: '專家訪談公司' },
  'comparison.headhunterLabel': { en: 'Headhunting Company', zh: '猎头公司', tc: '獵頭公司' },
  'comparison.expertNetworkLabel': { en: 'Expert Networks', zh: '专家网络', tc: '專家網絡' },
  'comparison.coreDeliverable': { en: 'Core Deliverable', zh: '核心交付物', tc: '核心交付物' },
  'comparison.ivcDeliverable': { en: 'C-Suite Leadership & Business Results (Fractional CxO/Advisors)', zh: 'C-Suite 领导力与业务结果（Fractional CxO/顾问）', tc: 'C-Suite 領導力與業務結果（Fractional CxO/顧問）' },
  'comparison.headhunterDeliverable': { en: 'Full-time Candidate List', zh: '全职人才候选人清单', tc: '全職人才候選人清單' },
  'comparison.expertNetworkDeliverable': { en: '60-Minute Expert Phone Consultation', zh: '60 分钟的临时智力访谈', tc: '60 分鐘的臨時智力訪談' },
  'comparison.engagement': { en: 'Engagement Depth & Duration', zh: '参与深度与时间', tc: '參與深度與時間' },
  'comparison.ivcEngagement': { en: 'Deep Engagement & Medium-Long Term (Embedded in enterprise, responsible for decisions, 3-12+ months)', zh: '深度参与 & 中长期（嵌入企业，负责决策，3-12个月+）', tc: '深度參與 & 中長期（嵌入企業，負責決策，3-12個月+）' },
  'comparison.headhunterEngagement': { en: 'Low Engagement & Short Term (Recruitment process ends)', zh: '低度参与 & 短期（完成招聘流程即结束）', tc: '低度參與 & 短期（完成招聘流程即結束）' },
  'comparison.expertNetworkEngagement': { en: 'Minimal Engagement & Very Short Term (Limited to 1-hour call)', zh: '极低参与 & 极短期（仅限 1 小时通话）', tc: '極低參與 & 極短期（僅限 1 小時通話）' },
  'comparison.coreValue': { en: 'Core Value', zh: '核心价值', tc: '核心價值' },
  'comparison.ivcValue': { en: 'Solves "Leadership Gap & Cross-Border Entry Barriers" (Execute Strategy)', zh: '解决 "领导力缺口 & 跨境准入障碍"（执行战略）', tc: '解決 "領導力缺口 & 跨境準入障礙"（執行戰略）' },
  'comparison.headhunterValue': { en: 'Solves "Full-time Headcount Gap" (Fill HC)', zh: '解决 "全职编制缺口"（填充HC）', tc: '解決 "全職編制缺口"（填充HC）' },
  'comparison.expertNetworkValue': { en: 'Solves "Information/Knowledge Asymmetry" (Get Facts)', zh: '解决 "信息/知识不对称"（获取事实）', tc: '解決 "信息/知識不對稱"（獲取事實）' },
  'comparison.aiApplication': { en: 'AI Application', zh: 'AI 应用场景', tc: 'AI 應用場景' },
  'comparison.ivcAI': { en: 'AI engine precisely matches expert brains + business needs', zh: 'AI 引擎精准匹配专家大脑 + 业务需求', tc: 'AI 引擎精准匹配專家大腦 + 業務需求' },
  'comparison.headhunterAI': { en: 'AI assists candidate resume search', zh: 'AI 辅助候选人简历搜索', tc: 'AI 輔助候選人簡歷搜索' },
  'comparison.expertNetworkAI': { en: 'AI assists expert database keyword matching', zh: 'AI 辅助专家库关键词匹配', tc: 'AI 輔助專家庫關鍵詞匹配' },
  'comparison.targetCustomer': { en: 'Target Customer', zh: '目标客户群', tc: '目標客戶群' },
  'comparison.ivcCustomer': { en: 'Chinese enterprises seeking overseas expansion or operational optimization, various foreign enterprises, and Hong Kong public institutions', zh: '寻求出海或运营优化的中企，各类外企和香港公营机构', tc: '尋求出海或運營優化的中企，各類外企和香港公營機構' },
  'comparison.headhunterCustomer': { en: 'All types of enterprises with human resources needs', zh: '各类有人力资源需求的公司', tc: '各類有人力資源需求的公司' },
  'comparison.expertNetworkCustomer': { en: 'Consulting firms and investment institutions', zh: '咨询公司和投资机构', tc: '諮詢公司和投資機構' },
  'comparison.typicalCase': { en: 'Typical Case (April Rolling Plan)', zh: '典型案例（4月 Rolling Plan）', tc: '典型案例（4月 Rolling Plan）' },
  'comparison.ivcCase': { en: 'ASTRI/MTR Project: IVC expert serves as part-time CBO, driving project implementation through AI matching.', zh: 'ASTRI/MTR 项目：IVC 专家作为非全职 CBO，通过 AI 匹配推动项目落地。', tc: 'ASTRI/MTR 項目：IVC 專家作為非全職 CBO，通過 AI 匹配推動項目落地。' },
  'comparison.headhunterCase': { en: 'MTR recruiting a full-time CTO.', zh: 'MTR 招聘一名全职 CTO。', tc: 'MTR 招聘一名全職 CTO。' },
  'comparison.expertNetworkCase': { en: 'Deloitte needs to consult with a Hong Kong Fintech policy expert on compliance details.', zh: '德勤需要约谈一位香港 Fintech 政策专家，了解合规细节。', tc: '德勤需要約談一位香港 Fintech 政策專家，了解合規細節。' },
  'comparison.pricingModel': { en: 'Pricing Model', zh: '收费模式', tc: '收費模式' },
  'comparison.ivcPricing': { en: 'Retainer + Success Fee (Reflects long-term value)', zh: 'Retainer + 成功费（反映长期价值）', tc: 'Retainer + 成功費（反映長期價值）' },
  'comparison.headhunterPricing': { en: 'Percentage of annual salary (One-time transaction)', zh: '按年薪百分比收费（一次性交易）', tc: '按年薪百分比收費（一次性交易）' },
  'comparison.expertNetworkPricing': { en: 'Hourly rate (Temporary transaction)', zh: '按小时计费（临时交易）', tc: '按小時計費（臨時交易）' },
  'comparison.competitiveAdvantage': { en: 'Competitive Advantage (Moat)', zh: '竞争优势（Moat）', tc: '競爭優勢（Moat）' },
  'comparison.ivcAdvantage': { en: 'Senior public sector leader endorsement + AI-driven precision delivery', zh: '公职机构高级领袖背书 + AI 驱动的精准交付', tc: '公職機構高級領袖背書 + AI 驱動的精準交付' },
  'comparison.headhunterAdvantage': { en: 'Breadth of industry talent network', zh: '行业人才网络广度', tc: '行業人才網絡廣度' },
  'comparison.expertNetworkAdvantage': { en: 'Large scale and comprehensive coverage of expert database', zh: '专家库的庞大规模与覆盖面', tc: '專家庫的龐大規模與覆蓋面' },
  'comparison.cta': { en: 'Ready to experience the IVC difference?', zh: '准备体验通微达观的差异化优势？', tc: '準備體驗通微達觀的差異化優勢？' },
  'comparison.ctaButton': { en: 'Schedule a Consultation', zh: '预约咨询', tc: '預約諮詢' },
  'comparison.pageTitle': { en: 'Why Choose InsightfulVision Consulting?', zh: '为什么选择通微达观', tc: '為什麼選擇通微達觀' },
  'comparison.pageSubtitle': { en: 'We differentiate ourselves through deep expertise, proven execution, and AI-powered precision matching.', zh: '我们通过深厚的专业能力、成熟的执行力和 AI 驱动的精准匹配而与众不同。', tc: '我們通過深厚的專業能力、成熟的執行力和 AI 驅動的精準匹配而與眾不同。' },
  'comparison.backToHome': { en: 'Back to Home', zh: '返回首页', tc: '返回首頁' },

  // Expert Matrix - Industries
  'industry.automotive': { en: 'Automotive', zh: '汽车', tc: '汽車' },
  'industry.manufacturing': { en: 'Manufacturing', zh: '制造', tc: '製造' },
  'industry.fmcg': { en: 'FMCG', zh: '快消', tc: '快消' },
  'industry.tmt': { en: 'TMT', zh: 'TMT', tc: 'TMT' },
  'industry.healthcare': { en: 'Healthcare', zh: '医疗', tc: '醫療' },
  'industry.publicService': { en: 'Public Service', zh: '公共服务', tc: '公共服務' },
  'industry.realestate': { en: 'Real Estate', zh: '地产', tc: '地產' },
  'industry.energy': { en: 'Energy', zh: '能源', tc: '能源' },
  'industry.education': { en: 'Education', zh: '教育', tc: '教育' },
  'industry.finance': { en: 'Finance', zh: '金融', tc: '金融' },
  'industry.other': { en: 'Other', zh: '其他', tc: '其他' },

  // Expert Matrix - Functions
  'function.strategy': { en: 'Strategy', zh: '战略', tc: '戰略' },
  'function.operations': { en: 'Operations', zh: '运营', tc: '運營' },
  'function.salesExpansion': { en: 'Sales Expansion', zh: '销售拓展', tc: '銷售拓展' },
  'function.riskControl': { en: 'Risk Control', zh: '风控', tc: '風控' },
  'function.finance': { en: 'Finance', zh: '财务', tc: '財務' },
  'function.it': { en: 'IT', zh: 'IT', tc: 'IT' },
  'function.hr': { en: 'HR', zh: '人力资源', tc: '人力資源' },
  'function.legal': { en: 'Legal', zh: '法务', tc: '法務' },
  'function.sustainability': { en: 'Sustainability', zh: '可持续发展', tc: '可持續發展' },
  'function.other': { en: 'Other', zh: '其他', tc: '其他' },

  // Expert Matrix - Special Capabilities
  'capability.goingGlobal': { en: 'Going Global', zh: '中企出海', tc: '中企出海' },
  'capability.mainlandHkConnectivity': { en: 'Mainland-HK Connectivity', zh: '陆港联通', tc: '陸港聯通' },
  'expertMatrix.title': { en: 'Expert Matrix: Industry × Function', zh: '专家矩阵：行业 × 职能', tc: '專家矩陣：行業 × 職能' },
  'expertMatrix.subtitle': { en: 'Click on any cell to explore experts in that industry-function intersection', zh: '点击任意单元格查看该行业-职能组合的专家', tc: '點擊任意單元格查看該行業-職能組合的專家' },
  'expertMatrix.goingGlobal': { en: 'Chinese Enterprises Going Global', zh: '中企出海', tc: '中企出海' },
  'expertMatrix.mainlandHkConnectivity': { en: 'Mainland-Hong Kong Connectivity', zh: '陆港联通', tc: '陸港聯通' },
  'expertMatrix.moreIndustries': { en: '... and more industries', zh: '... 及更多行业', tc: '... 及更多行業' },
  'expertMatrix.moreFunctions': { en: '... and more functions', zh: '... 及更多职能', tc: '... 及更多職能' },

  // Industry Insights
  'insights.title': { en: 'Industry Insights', zh: '行业洞察', tc: '行業洞察' },
  'insights.subtitle': { en: 'Deep insights on cross-border strategy, fractional leadership, and AI-driven business transformation.', zh: '关于跨境战略、Fractional领导力及AI驱动的业务转变的深度洞察。', tc: '關於跨境戰略、Fractional領導力及AI驅動的業務轉變的深度洞察。' },
  'insights.readMore': { en: 'Read Article', zh: '阅读全文', tc: '閱讀全文' },
  'insights.backToInsights': { en: 'Back to Insights', zh: '返回行业洞察', tc: '返回行業洞察' },
  'insights.shareArticle': { en: 'Share Article', zh: '分享文章', tc: '分享文章' },
  'insights.shareOn': { en: 'Share on', zh: '分享到', tc: '分享到' },
  'insights.copyLink': { en: 'Copy Link', zh: '复制链接', tc: '複製鏈接' },
  'insights.copied': { en: 'Link copied!', zh: '链接已复制', tc: '鏈接已複製' },
  'insights.article1.title': { en: 'Bridging the Gap Between "Light" and "Heavy": Why Fractional Leadership is a Strategic Imperative in the AI Era', zh: '跨越"轻"与"重"的鸿沟：AI 时代下的 Fractional Leadership 为何成为战略刚需？', tc: '跨越"輕"與"重"的鴻溝：AI 時代下的 Fractional Leadership 為何成為戰略剛需？' },
  'insights.article1.date': { en: 'March 31, 2026', zh: '2026年3月31日', tc: '2026年3月31日' },
  'insights.article1.excerpt': { en: 'In 2026, the global business environment is experiencing an unprecedented "granularity revolution." Enterprises face a dilemma between ultra-light AI solutions and heavy full-time executives. Fractional Leadership emerges as the third way.', zh: '在2026年的今天，全球商业环境正经历一场前所未有的"颗粒度革命"。企业决策者陷入"极轻"AI交付与"极重"全职高管之间的困境。Fractional Leadership成为第三条道路。', tc: '在2026年的今天，全球商業環境正經歷一場前所未有的"顆粒度革命"。企業決策者陷入"極輕"AI交付與"極重"全職高管之間的困境。Fractional Leadership成為第三條道路。' },

  // Article 2
  'insights.article2.title': { en: 'From "Talent Ownership" to "Capability Access": How AI-Driven Fractional Teams Rebuild Enterprise Resilience', zh: '从"人才拥有"到"能力接入"：AI 驱动的 Fractional 团队如何重构企业韧性？', tc: '從"人才擁有"到"能力接入"：AI 驅動的 Fractional 团隊如何重構企業韧性？' },
  'insights.article2.date': { en: 'April 15, 2026', zh: '2026年4月15日', tc: '2026年4月15日' },
  'insights.article2.excerpt': { en: 'Traditional talent acquisition models are becoming obsolete. Enterprises are shifting from "owning talent" to "accessing capability." Discover how AI-driven Fractional teams create organizational resilience and enable rapid scaling.', zh: '传统的人才获取模式正变得落伍。企业正从"拥有人才"转变为"接入能力"。了解 AI 驱动的 Fractional 团队如何打造组织韧性并实现快速扩展。', tc: '傳統的人才獲取模式正變得落伍。企業正從"擁有人才"轉變為"接入能力"。了解 AI 驅動的 Fractional 团隊如何打造組織韧性並實現快速擴展。' },

  // Article links
  'insights.readArticle1': { en: 'Read Part 1: Bridging the Gap Between "Light" and "Heavy"', zh: '阅读第一篇：跨越"轻"与"重"的鸿沟', tc: '閱讀第一篇：跨越"輕"與"重"的鴻溝' },
  'insights.readArticle2': { en: 'Read Part 2: From "Talent Ownership" to "Capability Access"', zh: '阅读第二篇：从"人才拥有"到"能力接入"', tc: '閱讀第二篇：從"人才擁有"到"能力接入"' },
  'insights.seriesLabel': { en: 'Series', zh: '系列文章', tc: '系列文章' },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = React.useState<Language>('zh');

  const t = (key: string): string => {
    const translation = translations[key];
    if (!translation) {
      console.warn(`Translation key not found: ${key}`);
      return key;
    }
    return translation[language];
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within LanguageProvider');
  }
  return context;
}

import React from 'react';
