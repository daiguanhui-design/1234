import { useLanguage } from '@/contexts/LanguageContext';
import { CheckCircle2, ThumbsUp } from 'lucide-react';

/**
 * Comparison Table Component
 * Showcases IVC's unique value proposition vs. traditional headhunters and expert networks
 */

export default function ComparisonTable() {
  const { language, t } = useLanguage();

  const comparisonData = [
    {
      dimension: t('comparison.coreDeliverable'),
      ivc: t('comparison.ivcDeliverable'),
      headhunter: t('comparison.headhunterDeliverable'),
      expertNetwork: t('comparison.expertNetworkDeliverable'),
    },
    {
      dimension: t('comparison.engagement'),
      ivc: t('comparison.ivcEngagement'),
      headhunter: t('comparison.headhunterEngagement'),
      expertNetwork: t('comparison.expertNetworkEngagement'),
    },
    {
      dimension: t('comparison.coreValue'),
      ivc: t('comparison.ivcValue'),
      headhunter: t('comparison.headhunterValue'),
      expertNetwork: t('comparison.expertNetworkValue'),
    },
    {
      dimension: t('comparison.aiApplication'),
      ivc: t('comparison.ivcAI'),
      headhunter: t('comparison.headhunterAI'),
      expertNetwork: t('comparison.expertNetworkAI'),
    },
    {
      dimension: t('comparison.targetCustomer'),
      ivc: t('comparison.ivcCustomer'),
      headhunter: t('comparison.headhunterCustomer'),
      expertNetwork: t('comparison.expertNetworkCustomer'),
    },
  ];

  return (
    <section 
      id="comparison" 
      className="py-20 px-4"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Title */}
        <div className="text-center mb-12">
          <h2 
            className="text-4xl md:text-5xl font-bold mb-4"
            style={{ color: '#0D1B2A', fontFamily: "'Playfair Display', serif" }}
          >
            {t('comparison.title')}
          </h2>
          <div 
            className="w-20 h-1 mx-auto mb-6"
            style={{ backgroundColor: '#D4AF37' }}
          />
          <p 
            className="text-lg max-w-2xl mx-auto"
            style={{ color: '#666666', fontFamily: "'Lato', sans-serif" }}
          >
            {t('comparison.subtitle')}
          </p>
        </div>

        {/* Comparison Table */}
        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr style={{ backgroundColor: '#0D1B2A' }}>
                <th 
                  className="px-6 py-4 text-left text-sm font-semibold border"
                  style={{ color: '#D4AF37', borderColor: '#D4AF37' }}
                >
                  {t('comparison.dimension')}
                </th>
                <th 
                  className="px-6 py-4 text-left text-sm font-semibold border"
                  style={{ color: '#0D1B2A', borderColor: '#D4AF37', backgroundColor: '#D4AF37' }}
                >
                  IVC
                </th>
                <th 
                  className="px-6 py-4 text-left text-sm font-semibold border"
                  style={{ color: '#999999', borderColor: '#D4AF37', backgroundColor: '#F0F0F0' }}
                >
                  {t('comparison.headhunterLabel')}
                </th>
                <th 
                  className="px-6 py-4 text-left text-sm font-semibold border"
                  style={{ color: '#999999', borderColor: '#D4AF37', backgroundColor: '#F0F0F0' }}
                >
                  {t('comparison.expertNetworkLabel')}
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonData.map((row, index) => (
                <tr 
                  key={index}
                  style={{ 
                    backgroundColor: index % 2 === 0 ? '#FFFFFF' : '#F5F5F5',
                    borderBottom: '1px solid #E0E0E0'
                  }}
                >
                  <td 
                    className="px-6 py-4 font-semibold text-sm"
                    style={{ color: '#0D1B2A', borderRight: '1px solid #E0E0E0' }}
                  >
                    {row.dimension}
                  </td>
                  <td 
                    className="px-6 py-4 text-sm"
                    style={{ color: '#0D1B2A', backgroundColor: '#FEF9E7', fontWeight: 600 }}
                  >
                    <div className="flex items-center gap-2">
                      <ThumbsUp size={18} style={{ color: '#D4AF37', flexShrink: 0 }} />
                      <span>{row.ivc}</span>
                    </div>
                  </td>
                  <td 
                    className="px-6 py-4 text-sm"
                    style={{ color: '#999999', backgroundColor: '#F9F9F9' }}
                  >
                    {row.headhunter}
                  </td>
                  <td 
                    className="px-6 py-4 text-sm"
                    style={{ color: '#999999', backgroundColor: '#F9F9F9' }}
                  >
                    {row.expertNetwork}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Bottom CTA */}
        <div className="mt-12 text-center">
          <p 
            className="text-sm mb-6"
            style={{ color: '#666666', fontFamily: "'Lato', sans-serif" }}
          >
            {t('comparison.cta')}
          </p>
          <button
            onClick={() => {
              const subject = encodeURIComponent('Consultation Request');
              const body = encodeURIComponent('Name: \nPosition: \nCompany: \nInquiry Category: \nChallenge: \nPhone: ');
              window.location.href = `mailto:contact@ivchk.com?subject=${subject}&body=${body}`;
            }}
            className="px-8 py-3 rounded-lg font-semibold transition-all duration-300 hover:shadow-lg cursor-pointer border-none"
            style={{ 
              backgroundColor: '#D4AF37',
              color: '#0D1B2A'
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
              (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.3)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLElement).style.boxShadow = 'none';
            }}
          >
            {t('comparison.ctaButton')}
          </button>
        </div>
      </div>
    </section>
  );
}
