import { useLanguage } from '@/contexts/LanguageContext';

/**
 * Hero Section Component
 * Design Philosophy: Premium Business Elegance
 * - Full-width background image with geometric patterns
 * - Elegant typography with Playfair Display
 * - Gold accent elements
 * - Responsive layout with overlay
 * - Bilingual support
 */

interface HeroSectionProps {
  onConsultClick?: () => void;
  onExpertsClick?: () => void;
}

export default function HeroSection({ onConsultClick, onExpertsClick }: HeroSectionProps) {
  const { t } = useLanguage();
  const heroImage = 'https://d2xsxph8kpxj0f.cloudfront.net/310519663057459414/VBszYB37tyvgAb3df5Rcv5/hero-background-PpncVWPhGz8wcEXwT7TgyW.webp';

  return (
    <section 
      id="hero"
      className="relative w-full min-h-screen flex items-center justify-center overflow-hidden"
      style={{
        backgroundImage: `url(${heroImage})`,
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundAttachment: 'fixed',
      }}
    >
      {/* Overlay */}
      <div 
        className="absolute inset-0"
        style={{
          backgroundColor: 'rgba(13, 27, 42, 0.4)',
        }}
      />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-3xl mx-auto text-center">
          {/* Main Title */}
          <h1 
            className="mb-6 leading-tight whitespace-pre-line"
            style={{
              color: '#FFFBF0',
              fontSize: 'clamp(2.5rem, 8vw, 4rem)',
              fontFamily: "'Playfair Display', serif",
              fontWeight: 800,
              letterSpacing: '-0.02em',
            }}
          >
            {t('hero.title')}
          </h1>

          {/* Subtitle */}
          <p 
            className="mb-8 text-lg md:text-xl leading-relaxed whitespace-pre-line"
            style={{
              color: '#E8E8E8',
              fontFamily: "'Lato', sans-serif",
              fontWeight: 400,
            }}
          >
            {t('hero.subtitle')}
          </p>

          {/* Gold Divider */}
          <div className="flex justify-center mb-8">
            <div style={{ width: '60px', height: '2px', backgroundColor: '#D4AF37' }} />
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <button
              onClick={() => {
                const subject = encodeURIComponent('Consultation Request');
                const body = encodeURIComponent('Name: \nPosition: \nCompany: \nInquiry Category: \nChallenge: \nPhone: ');
                window.location.href = `mailto:contact@ivchk.com?subject=${subject}&body=${body}`;
              }}
              className="px-8 py-4 rounded text-lg font-semibold transition-all duration-300 hover:shadow-lg cursor-pointer border-none"
              style={{
                backgroundColor: '#D4AF37',
                color: '#0D1B2A',
                fontFamily: "'Lato', sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.3)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLElement).style.boxShadow = 'none';
              }}
            >
              {t('hero.cta1')}
            </button>
            <button
              onClick={onExpertsClick}
              className="px-8 py-4 rounded text-lg font-semibold transition-all duration-300 border-2 hover:shadow-lg"
              style={{
                backgroundColor: 'transparent',
                color: '#FFFBF0',
                borderColor: '#FFFBF0',
                fontFamily: "'Lato', sans-serif",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.backgroundColor = 'rgba(255, 251, 240, 0.1)';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
              }}
            >
              {t('hero.cta2')}
            </button>
          </div>

          {/* Scroll Indicator */}
          <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
            <svg 
              className="w-6 h-6" 
              style={{ color: '#D4AF37' }}
              fill="none" 
              stroke="currentColor" 
              viewBox="0 0 24 24"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
}
