import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import {
  expertMappings,
  getAllIndustries,
  getAllFunctions,
  getExpertsForIntersection,
  getExpertsWithCapability,
  industryConfig,
  functionConfig,
  type Industry,
  type Function as FunctionType,
  type SpecialCapability,
} from '@/data/expertMatrixData';

interface SelectedCell {
  industry: Industry | null;
  function: FunctionType | null;
}

export default function ExpertMatrixNew() {
  const { t } = useLanguage();
  const [selectedCell, setSelectedCell] = useState<SelectedCell>({ industry: null, function: null });
  const [selectedCapability, setSelectedCapability] = useState<SpecialCapability>('none');

  const industries = getAllIndustries();
  const functions = getAllFunctions();

  // Get experts for selected cell
  const selectedExperts =
    selectedCell.industry && selectedCell.function
      ? getExpertsForIntersection(selectedCell.industry, selectedCell.function)
      : [];

  // Get experts for selected capability
  const capabilityExperts =
    selectedCapability !== 'none' ? getExpertsWithCapability(selectedCapability) : [];

  // Get count of experts for each cell
  const getExpertCount = (industry: Industry, func: FunctionType): number => {
    return getExpertsForIntersection(industry, func).length;
  };

  // Get heatmap color based on expert count
  const getHeatmapColor = (count: number): string => {
    // Find max count across all cells for normalization
    const allCounts = industries.flatMap(ind => 
      functions.map(func => getExpertCount(ind, func))
    );
    const maxCount = Math.max(...allCounts, 1);
    const minCount = Math.min(...allCounts, 0);
    
    // Normalize count to 0-1 range
    const normalized = maxCount === minCount ? 0.5 : (count - minCount) / (maxCount - minCount);
    
    // Red to Green gradient
    // Red: RGB(255, 76, 76) #FF4C4C
    // Yellow: RGB(255, 193, 7) #FFC107
    // Green: RGB(76, 175, 80) #4CAF50
    
    if (normalized < 0.5) {
      // Red to Yellow (0 to 0.5)
      const t = normalized * 2; // 0 to 1
      const r = 255;
      const g = Math.round(76 + (193 - 76) * t);
      const b = Math.round(76 + (7 - 76) * t);
      return `rgb(${r}, ${g}, ${b})`;
    } else {
      // Yellow to Green (0.5 to 1)
      const t = (normalized - 0.5) * 2; // 0 to 1
      const r = Math.round(255 - (255 - 76) * t);
      const g = Math.round(193 - (193 - 175) * t);
      const b = Math.round(7 + (80 - 7) * t);
      return `rgb(${r}, ${g}, ${b})`;
    }
  };

  return (
    <section
      id="experts"
      className="py-20 md:py-32 relative overflow-hidden"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      {/* Background Pattern */}
      <div
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage:
            'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663057459414/VBszYB37tyvgAb3df5Rcv5/expert-matrix-bg-aSiYWwvmndmBxNhxMiDxQS.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2
            style={{
              color: '#0D1B2A',
              fontFamily: "'Playfair Display', serif",
              fontWeight: 800,
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              letterSpacing: '-0.02em',
            }}
          >
            {t('expertMatrix.title')}
          </h2>
          <div className="flex justify-center mt-4">
            <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
          </div>
          <p
            className="mt-6 text-lg max-w-2xl mx-auto"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
            }}
          >
            {t('expertMatrix.subtitle')}
          </p>
        </div>

        {/* Special Capabilities Section */}
        <div className="mb-12 grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Going Global */}
          <div
            className="p-8 rounded-lg cursor-pointer transition-all duration-300"
            style={{
              backgroundColor: selectedCapability === 'goingGlobal' ? '#FFF3E0' : '#FFFFFF',
              border:
                selectedCapability === 'goingGlobal'
                  ? '2px solid #FF9800'
                  : '2px solid #E5E5E5',
            }}
            onClick={() => setSelectedCapability(selectedCapability === 'goingGlobal' ? 'none' : 'goingGlobal')}
          >
            <div className="flex items-center mb-4">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                style={{ backgroundColor: '#FF9800', color: '#FFFFFF' }}
              >
                🌍
              </div>
              <h3
                className="ml-4 text-xl font-bold"
                style={{ color: '#0D1B2A', fontFamily: "'Playfair Display', serif" }}
              >
                {t('expertMatrix.goingGlobal')}
              </h3>
            </div>
            <p style={{ color: '#666666', fontFamily: "'Lato', sans-serif" }}>
              {getExpertsWithCapability('goingGlobal').length} experts specializing in Chinese enterprises
              going global
            </p>
          </div>

          {/* Mainland-HK Connectivity */}
          <div
            className="p-8 rounded-lg cursor-pointer transition-all duration-300"
            style={{
              backgroundColor: selectedCapability === 'mainlandHkConnectivity' ? '#E3F2FD' : '#FFFFFF',
              border:
                selectedCapability === 'mainlandHkConnectivity'
                  ? '2px solid #2196F3'
                  : '2px solid #E5E5E5',
            }}
            onClick={() =>
              setSelectedCapability(selectedCapability === 'mainlandHkConnectivity' ? 'none' : 'mainlandHkConnectivity')
            }
          >
            <div className="flex items-center mb-4">
              <div
                className="w-12 h-12 rounded-full flex items-center justify-center text-2xl"
                style={{ backgroundColor: '#2196F3', color: '#FFFFFF' }}
              >
                🌉
              </div>
              <h3
                className="ml-4 text-xl font-bold"
                style={{ color: '#0D1B2A', fontFamily: "'Playfair Display', serif" }}
              >
                {t('expertMatrix.mainlandHkConnectivity')}
              </h3>
            </div>
            <p style={{ color: '#666666', fontFamily: "'Lato', sans-serif" }}>
              {getExpertsWithCapability('mainlandHkConnectivity').length} experts bridging Mainland and Hong
              Kong markets
            </p>
          </div>
        </div>

        {/* Industry × Function Matrix */}
        <div className="mb-12 overflow-x-auto">
          <table
            className="w-full border-collapse"
            style={{
              backgroundColor: '#FFFFFF',
              border: '2px solid #D4AF37',
              borderRadius: '8px',
              overflow: 'hidden',
            }}
          >
            <thead>
              <tr style={{ backgroundColor: '#0D1B2A' }}>
                <th
                  style={{
                    color: '#FFFFFF',
                    padding: '12px',
                    textAlign: 'left',
                    fontFamily: "'Lato', sans-serif",
                    fontWeight: 600,
                    borderRight: '1px solid #D4AF37',
                  }}
                >
                  Industry / Function
                </th>
                {functions.map((func) => (
                  <th
                    key={func}
                    style={{
                      color: '#D4AF37',
                      padding: '12px',
                      textAlign: 'center',
                      fontFamily: "'Lato', sans-serif",
                      fontWeight: 600,
                      fontSize: '0.875rem',
                      borderRight: '1px solid #D4AF37',
                    }}
                  >
                    <div>{functionConfig[func].icon}</div>
                    <div>{t(`function.${func}`)}</div>
                  </th>
                ))}
                <th
                  style={{
                    color: '#D4AF37',
                    padding: '12px',
                    textAlign: 'center',
                    fontFamily: "'Lato', sans-serif",
                    fontWeight: 600,
                    fontSize: '0.875rem',
                  }}
                >
                  ...
                </th>
              </tr>
            </thead>
            <tbody>
              {industries.map((industry, rowIndex) => (
                <tr
                  key={industry}
                  style={{
                    borderBottom: rowIndex < industries.length - 1 ? '1px solid #E5E5E5' : 'none',
                  }}
                >
                  <td
                    style={{
                      padding: '12px',
                      fontFamily: "'Lato', sans-serif",
                      fontWeight: 600,
                      color: '#0D1B2A',
                      backgroundColor: '#F9F9F9',
                      borderRight: '1px solid #D4AF37',
                    }}
                  >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                      <div
                        style={{
                          width: '12px',
                          height: '12px',
                          borderRadius: '2px',
                          backgroundColor: industryConfig[industry].color,
                        }}
                      />
                      {t(`industry.${industry}`)}
                    </div>
                  </td>
                  {functions.map((func) => {
                    const count = getExpertCount(industry, func);
                    const isSelected = selectedCell.industry === industry && selectedCell.function === func;
                    return (
                      <td
                        key={`${industry}-${func}`}
                        onClick={() =>
                          setSelectedCell(
                            isSelected ? { industry: null, function: null } : { industry, function: func }
                          )
                        }
                        style={{
                          padding: '12px',
                          textAlign: 'center',
                          cursor: 'pointer',
                          backgroundColor: isSelected ? '#FFF9E6' : getHeatmapColor(count),
                          borderRight: '1px solid #E5E5E5',
                          transition: 'all 0.3s ease',
                          borderBottom: '1px solid #E5E5E5',
                        }}
                        onMouseEnter={(e) => {
                          if (!isSelected) {
                            const currentBg = (e.currentTarget as HTMLElement).style.backgroundColor;
                            (e.currentTarget as HTMLElement).style.backgroundColor = currentBg;
                            (e.currentTarget as HTMLElement).style.borderBottom = '2px solid #D4AF37';
                            (e.currentTarget as HTMLElement).style.boxShadow = '0 0 8px rgba(212, 175, 55, 0.3)';
                          }
                        }}
                        onMouseLeave={(e) => {
                          if (!isSelected) {
                            (e.currentTarget as HTMLElement).style.backgroundColor = getHeatmapColor(count);
                            (e.currentTarget as HTMLElement).style.borderBottom = '1px solid #E5E5E5';
                            (e.currentTarget as HTMLElement).style.boxShadow = 'none';
                          }
                        }}
                      >
                        <div
                          style={{
                            fontFamily: "'Lato', sans-serif",
                            fontWeight: isSelected ? 700 : 600,
                            color: isSelected ? '#D4AF37' : '#0D1B2A',
                            fontSize: '1.125rem',
                          }}
                        >
                          {count}
                        </div>
                      </td>
                    );
                  })}
                  <td
                    style={{
                      padding: '12px',
                      textAlign: 'center',
                      color: '#999999',
                      fontFamily: "'Lato', sans-serif",
                    }}
                  >
                    ...
                  </td>
                </tr>
              ))}
              <tr>
                <td
                  style={{
                    padding: '12px',
                    fontFamily: "'Lato', sans-serif",
                    fontWeight: 600,
                    color: '#999999',
                    backgroundColor: '#F9F9F9',
                    borderRight: '1px solid #D4AF37',
                  }}
                >
                  ...
                </td>
                {functions.map((func) => (
                  <td
                    key={`ellipsis-${func}`}
                    style={{
                      padding: '12px',
                      textAlign: 'center',
                      color: '#999999',
                      fontFamily: "'Lato', sans-serif",
                      borderRight: '1px solid #E5E5E5',
                    }}
                  >
                    ...
                  </td>
                ))}
                <td
                  style={{
                    padding: '12px',
                    textAlign: 'center',
                    color: '#999999',
                    fontFamily: "'Lato', sans-serif",
                  }}
                >
                  ...
                </td>
              </tr>
            </tbody>
          </table>
        </div>

        {/* Selected Experts Display */}
        {(selectedExperts.length > 0 || capabilityExperts.length > 0) && (
          <div className="mb-12">
            <h3
              style={{
                color: '#0D1B2A',
                fontFamily: "'Playfair Display', serif",
                fontSize: '1.75rem',
                fontWeight: 700,
                marginBottom: '16px',
              }}
            >
              {selectedCell.industry && selectedCell.function
                ? `${t(`industry.${selectedCell.industry}`)} × ${t(`function.${selectedCell.function}`)}`
                : selectedCapability !== 'none'
                  ? t(`expertMatrix.${selectedCapability}`)
                  : 'Select a cell or capability'}
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              {(selectedExperts.length > 0 ? selectedExperts : capabilityExperts).map((expert) => {
                const expertData = expertMappings.find((e) => e.id === expert.id);
                if (!expertData) return null;

                return (
                  <div
                    key={expert.id}
                    className="rounded-lg p-6 transition-all duration-500"
                    style={{
                      backgroundColor: '#FFFFFF',
                      border: '2px solid #E5E5E5',
                    }}
                    onMouseEnter={(e) => {
                      const element = e.currentTarget as HTMLElement;
                      element.style.borderColor = '#D4AF37';
                      element.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.15)';
                      element.style.transform = 'translateY(-4px)';
                    }}
                    onMouseLeave={(e) => {
                      const element = e.currentTarget as HTMLElement;
                      element.style.borderColor = '#E5E5E5';
                      element.style.boxShadow = 'none';
                      element.style.transform = 'translateY(0)';
                    }}
                  >
                    {/* Avatar Circle */}
                    <div
                      className="w-16 h-16 rounded-full flex items-center justify-center mb-4 text-white text-2xl font-bold"
                      style={{ backgroundColor: '#D4AF37' }}
                    >
                      {t(expert.nameKey).charAt(0)}
                    </div>

                    {/* Expert Info */}
                    <h4
                      className="mb-2"
                      style={{
                        color: '#0D1B2A',
                        fontFamily: "'Playfair Display', serif",
                        fontSize: '1.25rem',
                        fontWeight: 700,
                      }}
                    >
                      {t(expert.nameKey)}
                    </h4>

                    <p
                      className="mb-3 text-sm"
                      style={{
                        color: '#D4AF37',
                        fontFamily: "'Lato', sans-serif",
                        fontWeight: 600,
                      }}
                    >
                      {t(`expert.${expert.id}.title`)}
                    </p>

                    {/* Special Capabilities */}
                    {expertData.specialCapabilities.length > 0 && (
                      <div className="flex flex-wrap gap-2 mb-4">
                        {expertData.specialCapabilities.map((cap) => (
                          <span
                            key={cap}
                            className="text-xs px-2 py-1 rounded-full"
                            style={{
                              backgroundColor: cap === 'goingGlobal' ? '#FFE0B2' : '#BBDEFB',
                              color: cap === 'goingGlobal' ? '#E65100' : '#0D47A1',
                              fontFamily: "'Lato', sans-serif",
                              fontWeight: 600,
                            }}
                          >
                            {cap === 'goingGlobal' ? '🌍' : '🌉'} {t(`capability.${cap}`)}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p
            className="text-lg mb-6"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
            }}
          >
            {t('experts.collaborate')}
          </p>
          <button
            onClick={() => {
              const subject = encodeURIComponent('Consultation Request');
              const body = encodeURIComponent(
                'Name: \nPosition: \nCompany: \nInquiry Category: \nChallenge: \nPhone: '
              );
              window.location.href = `mailto:contact@ivchk.com?subject=${subject}&body=${body}`;
            }}
            className="px-8 py-4 rounded text-lg font-semibold transition-all duration-300 cursor-pointer border-none"
            style={{
              backgroundColor: '#D4AF37',
              color: '#0D1B2A',
              fontFamily: "'Lato', sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
              (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.3)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLElement).style.boxShadow = 'none';
            }}
          >
            {t('experts.cta')}
          </button>
        </div>
      </div>
    </section>
  );
}
