import { useLanguage } from '@/contexts/LanguageContext';

/**
 * Expert Matrix Component
 * Design Philosophy: Premium Business Elegance
 * - Showcase expert profiles with elegant cards
 * - Gold accent elements
 * - Responsive grid layout
 * - Professional typography
 * - Trilingual support
 */

interface Expert {
  id: number;
  nameKey: string;
  titleKey: string;
  backgroundKey: string;
  expertiseKey: string;
}

const experts: Expert[] = Array.from({ length: 20 }, (_, i) => ({
  id: i + 1,
  nameKey: `expert.${i + 1}.name`,
  titleKey: `expert.${i + 1}.title`,
  backgroundKey: `expert.${i + 1}.background`,
  expertiseKey: `expert.${i + 1}.expertise`,
}));

export default function ExpertMatrix() {
  const { t } = useLanguage();

  return (
    <section 
      id="experts"
      className="py-20 md:py-32 relative overflow-hidden"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      {/* Background Pattern */}
      <div 
        className="absolute inset-0 opacity-5"
        style={{
          backgroundImage: 'url(https://d2xsxph8kpxj0f.cloudfront.net/310519663057459414/VBszYB37tyvgAb3df5Rcv5/expert-matrix-bg-aSiYWwvmndmBxNhxMiDxQS.webp)',
          backgroundSize: 'cover',
          backgroundPosition: 'center',
        }}
      />

      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            style={{
              color: '#0D1B2A',
              fontFamily: "'Playfair Display', serif",
              fontWeight: 800,
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              letterSpacing: '-0.02em',
            }}
          >
            {t('experts.title')}
          </h2>
          <div className="flex justify-center mt-4">
            <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
          </div>
          <p 
            className="mt-6 text-lg max-w-2xl mx-auto"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
            }}
          >
            {t('experts.subtitle')}
          </p>
        </div>

          {/* Expert Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {experts.map((expert) => {
            const name = t(expert.nameKey);
            const title = t(expert.titleKey);
            const background = t(expert.backgroundKey);
            const expertise = t(expert.expertiseKey);

            return (
              <div
                key={expert.id}
                className="rounded-lg p-6 transition-all duration-500"
                style={{
                  backgroundColor: '#FFFFFF',
                  border: '2px solid #E5E5E5',
                }}
                onMouseEnter={(e) => {
                  const element = e.currentTarget as HTMLElement;
                  element.style.borderColor = '#D4AF37';
                  element.style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.15)';
                  element.style.transform = 'translateY(-4px)';
                }}
                onMouseLeave={(e) => {
                  const element = e.currentTarget as HTMLElement;
                  element.style.borderColor = '#E5E5E5';
                  element.style.boxShadow = 'none';
                  element.style.transform = 'translateY(0)';
                }}
              >
                {/* Avatar Circle */}
                <div 
                  className="w-16 h-16 rounded-full flex items-center justify-center mb-4 text-white text-2xl font-bold"
                  style={{ backgroundColor: '#D4AF37' }}
                >
                  {name.charAt(0)}
                </div>

                {/* Expert Info */}
                <h3 
                  className="mb-2"
                  style={{
                    color: '#0D1B2A',
                    fontFamily: "'Playfair Display', serif",
                    fontSize: '1.25rem',
                    fontWeight: 700,
                  }}
                >
                  {name}
                </h3>

                <p 
                  className="mb-3 text-sm"
                  style={{
                    color: '#D4AF37',
                    fontFamily: "'Lato', sans-serif",
                    fontWeight: 600,
                  }}
                >
                  {title}
                </p>

                <p 
                  className="mb-4 text-sm leading-relaxed"
                  style={{
                    color: '#666666',
                    fontFamily: "'Lato', sans-serif",
                  }}
                >
                  {background}
                </p>

                {/* Expertise Tags */}
                <div className="flex flex-wrap gap-2">
                  {expertise.split('、').map((skill, index) => (
                    <span
                      key={index}
                      className="text-xs px-3 py-1 rounded-full"
                      style={{
                        backgroundColor: '#F0F0F0',
                        color: '#0D1B2A',
                        fontFamily: "'Lato', sans-serif",
                      }}
                    >
                      {skill.trim()}
                    </span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <p 
            className="text-lg mb-6"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
            }}
          >
            {t('experts.collaborate')}
          </p>
          <button
            onClick={() => {
              const subject = encodeURIComponent('Consultation Request');
              const body = encodeURIComponent('Name: \nPosition: \nCompany: \nInquiry Category: \nChallenge: \nPhone: ');
              window.location.href = `mailto:contact@ivchk.com?subject=${subject}&body=${body}`;
            }}
            className="px-8 py-4 rounded text-lg font-semibold transition-all duration-300 cursor-pointer border-none"
            style={{
              backgroundColor: '#D4AF37',
              color: '#0D1B2A',
              fontFamily: "'Lato', sans-serif",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
              (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.3)';
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
              (e.currentTarget as HTMLElement).style.boxShadow = 'none';
            }}
          >
            {t('experts.cta')}
          </button>
        </div>
      </div>
    </section>
  );
}
