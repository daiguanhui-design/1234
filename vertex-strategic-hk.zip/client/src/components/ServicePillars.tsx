import { useLanguage } from '@/contexts/LanguageContext';
import { Zap, Globe, Users } from 'lucide-react';

/**
 * Service Pillars Component - 2+1 Strategic Layout
 * Design Philosophy: Premium Business Elegance
 * - Two flagship service cards in top row
 * - One foundational AI engine bar below
 * - Professional minimalist icons
 * - Gold accent elements
 * - Responsive grid layout
 * - Trilingual support
 */

interface Service {
  titleKey: string;
  descKey: string;
  icon: React.ReactNode;
  isFoundation?: boolean;
}

export default function ServicePillars() {
  const { t } = useLanguage();

  const services: Service[] = [
    {
      titleKey: 'services.service1.title',
      descKey: 'services.service1.desc',
      icon: <Globe size={48} strokeWidth={1.5} />,
    },
    {
      titleKey: 'services.service2.title',
      descKey: 'services.service2.desc',
      icon: <Users size={48} strokeWidth={1.5} />,
    },
    {
      titleKey: 'services.service3.title',
      descKey: 'services.service3.desc',
      icon: <Zap size={48} strokeWidth={1.5} />,
      isFoundation: true,
    },
  ];

  const flagshipServices = services.slice(0, 2);
  const foundationService = services[2];

  return (
    <section 
      id="services"
      className="py-20 md:py-32"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            style={{
              color: '#0D1B2A',
              fontFamily: "'Playfair Display', serif",
              fontWeight: 800,
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              letterSpacing: '-0.02em',
            }}
          >
            {t('services.title')}
          </h2>
          <div className="flex justify-center mt-4">
            <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
          </div>
          <p 
            className="mt-6 text-lg max-w-3xl mx-auto"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
              lineHeight: 1.6,
            }}
          >
            {t('services.subtitle')}
          </p>
        </div>

        {/* Flagship Services - 2 Column Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 mb-12">
          {flagshipServices.map((service, index) => (
            <div
              key={index}
              className="rounded-lg overflow-hidden transition-all duration-500 hover:shadow-2xl cursor-pointer"
              style={{
                backgroundColor: '#FFFFFF',
                border: '1px solid #E5E5E5',
                boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08)',
              }}
              onClick={() => {
                // Services section is already visible, no need to scroll
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-8px)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 16px 32px rgba(0, 0, 0, 0.12)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 4px 16px rgba(0, 0, 0, 0.08)';
              }}
            >
              {/* Icon Section */}
              <div 
                className="p-8 flex items-center justify-center"
                style={{
                  backgroundColor: '#F8F8F8',
                  borderBottom: '2px solid #D4AF37',
                }}
              >
                <div style={{ color: '#D4AF37' }}>
                  {service.icon}
                </div>
              </div>

              {/* Content Section */}
              <div className="p-8">
                <h3 
                  className="text-xl md:text-2xl font-bold mb-4"
                  style={{
                    color: '#0D1B2A',
                    fontFamily: "'Playfair Display', serif",
                    letterSpacing: '-0.01em',
                  }}
                >
                  {t(service.titleKey)}
                </h3>
                <p 
                  className="text-base leading-relaxed"
                  style={{
                    color: '#2C3E50',
                    fontFamily: "'Lato', sans-serif",
                    lineHeight: 1.7,
                  }}
                >
                  {t(service.descKey)}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Foundation Service - Full Width Bar */}
        <div
          className="rounded-lg overflow-hidden transition-all duration-500 cursor-pointer"
          style={{
            backgroundColor: '#0D1B2A',
            border: '2px solid #D4AF37',
            boxShadow: '0 8px 24px rgba(212, 175, 55, 0.2)',
          }}
          onClick={() => {
            // Foundation service section is already visible
          }}
          onMouseEnter={(e) => {
            (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 32px rgba(212, 175, 55, 0.3)';
          }}
          onMouseLeave={(e) => {
            (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.2)';
          }}
        >
          <div className="p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center gap-8">
            {/* Icon */}
            <div 
              className="flex-shrink-0 flex items-center justify-center"
              style={{
                width: '80px',
                height: '80px',
                backgroundColor: 'rgba(212, 175, 55, 0.1)',
                borderRadius: '12px',
                color: '#D4AF37',
              }}
            >
              {foundationService?.icon}
            </div>

            {/* Content */}
            <div className="flex-grow">
              <h3 
                className="text-2xl md:text-3xl font-bold mb-3"
                style={{
                  color: '#D4AF37',
                  fontFamily: "'Playfair Display', serif",
                  letterSpacing: '-0.01em',
                }}
              >
                {t(foundationService?.titleKey || '')}
              </h3>
              <p 
                className="text-base leading-relaxed"
                style={{
                  color: '#FFFBF0',
                  fontFamily: "'Lato', sans-serif",
                  lineHeight: 1.7,
                }}
              >
                {t(foundationService?.descKey || '')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
