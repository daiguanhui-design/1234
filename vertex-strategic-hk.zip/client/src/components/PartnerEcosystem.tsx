import { useLanguage } from '@/contexts/LanguageContext';
import { Building2, Globe, Briefcase } from 'lucide-react';

/**
 * Served Clients Component
 * Design Philosophy: Premium Business Elegance
 * - Display served clients in professional card grid
 * - Categorized by client type
 * - Gold accent elements
 * - Professional typography
 * - Responsive layout
 * - Trilingual support
 */

interface Client {
  nameKey: string;
  icon: React.ReactNode;
  category: string;
}

export default function PartnerEcosystem() {
  const { t } = useLanguage();

  const clients: Client[] = [
    { 
      nameKey: 'client.1.name', 
      icon: <Building2 size={40} strokeWidth={1.5} />,
      category: 'Government'
    },
    { 
      nameKey: 'client.2.name', 
      icon: <Briefcase size={40} strokeWidth={1.5} />,
      category: 'State Enterprise'
    },
    { 
      nameKey: 'client.3.name', 
      icon: <Briefcase size={40} strokeWidth={1.5} />,
      category: 'Provincial SOE'
    },
    { 
      nameKey: 'client.4.name', 
      icon: <Globe size={40} strokeWidth={1.5} />,
      category: 'Multinational'
    },
    { 
      nameKey: 'client.5.name', 
      icon: <Globe size={40} strokeWidth={1.5} />,
      category: 'International'
    },
  ];

  return (
    <section 
      id="partners"
      className="py-20 md:py-32"
      style={{ backgroundColor: '#FFFFFF' }}
    >
      <div className="container mx-auto px-4">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 
            style={{
              color: '#0D1B2A',
              fontFamily: "'Playfair Display', serif",
              fontWeight: 800,
              fontSize: 'clamp(2rem, 5vw, 3.5rem)',
              letterSpacing: '-0.02em',
            }}
          >
            {t('partners.title')}
          </h2>
          <div className="flex justify-center mt-4">
            <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
          </div>
          <p 
            className="mt-6 text-lg max-w-3xl mx-auto mb-4"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
              lineHeight: 1.6,
            }}
          >
            {t('partners.subtitle')}
          </p>
          <p 
            className="text-base max-w-3xl mx-auto"
            style={{
              color: '#555555',
              fontFamily: "'Lato', sans-serif",
              lineHeight: 1.6,
            }}
          >
            {t('partners.description')}
          </p>
        </div>

        {/* Served Clients Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
          {clients.map((client, index) => (
            <div
              key={index}
              className="flex flex-col items-center justify-center p-8 rounded-lg transition-all duration-500 hover:shadow-xl"
              style={{
                backgroundColor: '#FFFBF0',
                border: '2px solid #E5E5E5',
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = '#D4AF37';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(-4px)';
                (e.currentTarget as HTMLElement).style.boxShadow = '0 12px 24px rgba(212, 175, 55, 0.15)';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor = '#E5E5E5';
                (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                (e.currentTarget as HTMLElement).style.boxShadow = 'none';
              }}
            >
              {/* Icon */}
              <div 
                className="mb-4 flex items-center justify-center"
                style={{ color: '#D4AF37' }}
              >
                {client.icon}
              </div>

              {/* Client Name */}
              <h3 
                className="text-center text-sm md:text-base font-semibold"
                style={{
                  color: '#0D1B2A',
                  fontFamily: "'Lato', sans-serif",
                  lineHeight: 1.5,
                }}
              >
                {t(client.nameKey)}
              </h3>
            </div>
          ))}
        </div>

        {/* Small Note */}
        <div className="text-center mt-12">
          <p 
            className="text-xs md:text-sm"
            style={{
              color: '#999999',
              fontFamily: "'Lato', sans-serif",
              lineHeight: 1.6,
            }}
          >
            {t('clients.note')}
          </p>
        </div>
      </div>
    </section>
  );
}
