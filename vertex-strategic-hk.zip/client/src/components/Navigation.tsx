import { useState } from 'react';
import { Menu, X } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';
import { useLocation } from 'wouter';

/**
 * Navigation Component
 * Design Philosophy: Premium Business Elegance
 * - Deep navy background with ivory text
 * - Gold accent for hover states
 * - Elegant spacing and typography
 * - Responsive mobile menu
 * - Trilingual support (English, Simplified Chinese, Traditional Chinese)
 */

interface NavigationProps {
  onContactClick?: () => void;
}

export default function Navigation({ onContactClick }: NavigationProps) {
  const [isOpen, setIsOpen] = useState(false);

  const { language, setLanguage, t } = useLanguage();
  const [, setLocation] = useLocation();

  const navItems = [
    { label: t('nav.about'), href: '#about' },
    { label: t('nav.services'), href: '#services' },
    { label: t('nav.experts'), href: '#experts' },
    { label: t('nav.insights'), href: '/insights', isRoute: true },
    { label: t('nav.partners'), href: '#partners' },
    { label: t('nav.contact'), href: '#contact' },
  ];

  const handleNavClick = (href: string, item: any) => {
    setIsOpen(false);
    
    if (item.isRoute) {
      setLocation(href);
    } else if (href === '#contact' && onContactClick) {
      onContactClick();
    } else {
      const element = document.querySelector(href);
      element?.scrollIntoView({ behavior: 'smooth' });
    }
  };



  const toggleLanguage = () => {
    const languages: Array<'en' | 'zh' | 'tc'> = ['en', 'zh', 'tc'];
    const currentIndex = languages.indexOf(language);
    const nextIndex = (currentIndex + 1) % languages.length;
    setLanguage(languages[nextIndex]);
  };

  const getLanguageLabel = () => {
    if (language === 'en') return 'EN / 中 / 繁';
    if (language === 'zh') return '英 / 中 / 繁';
    return '英 / 中 / 繁';
  };

  return (
    <nav className="sticky top-0 z-50 shadow-lg" style={{ backgroundColor: '#0D1B2A', color: '#FFFBF0' }}>
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div 
            className="flex items-center justify-center px-4 py-2 rounded-md"
            style={{ 
              backgroundColor: '#0D1B2A',
              color: '#FFFFFF',
              fontFamily: "'Playfair Display', serif",
              fontSize: '20px',
              fontWeight: 'bold',
              letterSpacing: '2px'
            }}
          >
            IVC
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <div key={item.label} className="relative">
                <button
                  onClick={() => handleNavClick(item.href, item)}
                  className="text-sm font-medium transition-all duration-300 hover:opacity-80 relative"
                  style={{ color: '#FFFBF0' }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = '#D4AF37';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = '#FFFBF0';
                  }}
                >
                  {item.label}
                </button>
                

              </div>
            ))}
          </div>

          {/* Language Toggle & Mobile Menu Button */}
          <div className="flex items-center gap-4">
            <button 
              onClick={toggleLanguage}
              className="text-sm font-medium px-3 py-1 rounded transition-all duration-300"
              style={{ 
                borderColor: '#D4AF37',
                color: '#D4AF37',
                border: '1px solid #D4AF37'
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.backgroundColor = '#D4AF37';
                (e.currentTarget as HTMLElement).style.color = '#0D1B2A';
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
                (e.currentTarget as HTMLElement).style.color = '#D4AF37';
              }}
            >
              {getLanguageLabel()}
            </button>
            <button
              className="md:hidden"
              onClick={() => setIsOpen(!isOpen)}
              style={{ color: '#FFFBF0' }}
            >
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden mt-4 pb-4" style={{ borderTop: '1px solid #333333' }}>
            {navItems.map((item) => (
              <button
                key={item.label}
                onClick={() => handleNavClick(item.href, item)}
                className="block w-full text-left px-4 py-3 text-sm font-medium transition-all duration-300"
                style={{ color: '#FFFBF0' }}
                onMouseEnter={(e) => {
                  (e.currentTarget as HTMLElement).style.backgroundColor = '#1A3A52';
                  (e.currentTarget as HTMLElement).style.color = '#D4AF37';
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent';
                  (e.currentTarget as HTMLElement).style.color = '#FFFBF0';
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
