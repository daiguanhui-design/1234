import { useLocation } from 'wouter';
import { useLanguage } from '@/contexts/LanguageContext';
import { ChevronRight } from 'lucide-react';

interface BreadcrumbItem {
  label: string;
  href: string;
}

export default function Breadcrumb() {
  const [location] = useLocation();
  const { language } = useLanguage();

  const getBreadcrumbs = (): BreadcrumbItem[] => {
    const breadcrumbs: BreadcrumbItem[] = [
      {
        label: language === 'en' ? 'Home' : language === 'tc' ? '首頁' : '首页',
        href: '/',
      },
    ];

    if (location === '/comparison') {
      breadcrumbs.push({
        label: language === 'en' ? 'Comparison' : language === 'tc' ? '對比' : '对比',
        href: '/comparison',
      });
    } else if (location === '/insights') {
      breadcrumbs.push({
        label: language === 'en' ? 'Insights' : language === 'tc' ? '行業洞察' : '行业洞察',
        href: '/insights',
      });
    } else if (location.startsWith('/insights/')) {
      breadcrumbs.push({
        label: language === 'en' ? 'Insights' : language === 'tc' ? '行業洞察' : '行业洞察',
        href: '/insights',
      });
      breadcrumbs.push({
        label: language === 'en' ? 'Article' : language === 'tc' ? '文章' : '文章',
        href: location,
      });
    }

    return breadcrumbs;
  };

  const breadcrumbs = getBreadcrumbs();

  // 只在非首页时显示面包屑
  if (breadcrumbs.length <= 1) {
    return null;
  }

  return (
    <nav className="bg-background border-b border-border py-3 px-4">
      <div className="container mx-auto">
        <div className="flex items-center gap-2 text-sm">
          {breadcrumbs.map((item, index) => (
            <div key={item.href} className="flex items-center gap-2">
              {index > 0 && <ChevronRight className="w-4 h-4 text-muted-foreground" />}
              {index === breadcrumbs.length - 1 ? (
                <span className="text-foreground font-medium">{item.label}</span>
              ) : (
                <a
                  href={item.href}
                  className="text-primary hover:underline transition-colors"
                >
                  {item.label}
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </nav>
  );
}
