import { Linkedin, Mail, Phone } from 'lucide-react';
import { useLanguage } from '@/contexts/LanguageContext';

/**
 * Footer Component
 * Design Philosophy: Premium Business Elegance
 * - Deep navy background with ivory text
 * - Gold accent elements
 * - Professional layout
 * - Contact information and links
 * - Trilingual support
 */

export default function Footer() {
  const { t } = useLanguage();

  return (
    <footer 
      className="pt-16 pb-8"
      style={{ backgroundColor: '#0D1B2A', color: '#FFFBF0' }}
    >
      <div className="container mx-auto px-4">
        {/* Main Footer Content */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Company Info */}
          <div>
            <div 
              className="flex items-center justify-center px-3 py-2 rounded-md mb-4 w-fit"
              style={{ 
                backgroundColor: '#0D1B2A',
                color: '#FFFFFF',
                fontFamily: "'Playfair Display', serif",
                fontSize: '16px',
                fontWeight: 'bold',
                letterSpacing: '1.5px',
                border: '1px solid #D4AF37'
              }}
            >
              IVC
            </div>
            <p 
              className="text-sm leading-relaxed"
              style={{
                color: '#CCCCCC',
                fontFamily: "'Lato', sans-serif",
              }}
            >
              {t('footer.about')}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 
              className="font-semibold mb-4"
              style={{ color: '#D4AF37', fontFamily: "'Lato', sans-serif" }}
            >
              {t('footer.quickLinks')}
            </h4>
            <ul className="space-y-2">
              {[
                { key: 'nav.about', href: '#about' },
                { key: 'nav.services', href: '#services' },
                { key: 'nav.experts', href: '#experts' },
                { key: 'nav.contact', href: '#contact' }
              ].map(item => (
                <li key={item.key}>
                  <a 
                    href={item.href}
                    onClick={(e) => {
                      e.preventDefault();
                      const element = document.querySelector(item.href);
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-sm transition-colors duration-300 hover:text-gold cursor-pointer"
                    style={{
                      color: '#CCCCCC',
                      fontFamily: "'Lato', sans-serif",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.color = '#D4AF37';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.color = '#CCCCCC';
                    }}
                  >
                    {t(item.key)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 
              className="font-semibold mb-4"
              style={{ color: '#D4AF37', fontFamily: "'Lato', sans-serif" }}
            >
              {t('footer.services')}
            </h4>
            <ul className="space-y-2">
              {['services.service1.title', 'services.service2.title', 'services.service3.title'].map(key => (
                <li key={key}>
                  <a 
                    href="#services"
                    onClick={(e) => {
                      e.preventDefault();
                      const element = document.querySelector('#services');
                      element?.scrollIntoView({ behavior: 'smooth' });
                    }}
                    className="text-sm transition-colors duration-300 cursor-pointer"
                    style={{
                      color: '#CCCCCC',
                      fontFamily: "'Lato', sans-serif",
                    }}
                    onMouseEnter={(e) => {
                      (e.currentTarget as HTMLElement).style.color = '#D4AF37';
                    }}
                    onMouseLeave={(e) => {
                      (e.currentTarget as HTMLElement).style.color = '#CCCCCC';
                    }}
                  >
                    {t(key)}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 
              className="font-semibold mb-4"
              style={{ color: '#D4AF37', fontFamily: "'Lato', sans-serif" }}
            >
              {t('footer.contact')}
            </h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <Mail size={18} style={{ color: '#D4AF37', marginTop: '2px' }} />
                <div>
                  <p className="text-sm" style={{ color: '#CCCCCC', fontFamily: "'Lato', sans-serif" }}>
                    {t('footer.email')}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <Phone size={18} style={{ color: '#D4AF37', marginTop: '2px' }} />
                <div>
                  <p className="text-sm" style={{ color: '#CCCCCC', fontFamily: "'Lato', sans-serif" }}>
                    {t('footer.phone')}
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3 mt-4">
                <a 
                  href="#"
                  className="transition-colors duration-300"
                  style={{ color: '#D4AF37' }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLElement).style.color = '#FFFBF0';
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLElement).style.color = '#D4AF37';
                  }}
                >
                  <Linkedin size={20} />
                </a>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div 
          style={{
            height: '1px',
            backgroundColor: '#1A3A52',
            margin: '2rem 0',
          }}
        />

        {/* Bottom Footer */}
        <div className="flex flex-col md:flex-row justify-center items-center gap-4">
          {/* Copyright */}
          <p 
            className="text-xs"
            style={{
              color: '#999999',
              fontFamily: "'Lato', sans-serif",
            }}
          >
            {t('footer.copyright')}
          </p>
        </div>
      </div>
    </footer>
  );
}
