import { useState } from 'react';
import { useLanguage } from '@/contexts/LanguageContext';
import { trpc } from '@/lib/trpc';
import { Loader2, CheckCircle } from 'lucide-react';

/**
 * Contact Form Component
 * Design Philosophy: Premium Business Elegance
 * - Elegant form with gold accents
 * - Professional typography
 * - Responsive layout
 * - Form validation
 * - Trilingual support
 * - Backend API integration with email notifications
 * - Clear user feedback on submission
 */

interface ContactFormProps {
  isVisible?: boolean;
}

interface FormData {
  name: string;
  position: string;
  company: string;
  category: 'government' | 'talent' | 'ai' | 'other';
  challenge: string;
  email: string;
  phone: string;
}

export default function ContactForm({ isVisible = true }: ContactFormProps) {
  const { language, t } = useLanguage();
  const [formData, setFormData] = useState<FormData>({
    name: '',
    position: '',
    company: '',
    category: 'government',
    challenge: '',
    email: '',
    phone: '',
  });

  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Use tRPC mutation to submit form
  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setError(null);
      setTimeout(() => {
        setSubmitted(false);
        setFormData({
          name: '',
          position: '',
          company: '',
          category: 'government',
          challenge: '',
          email: '',
          phone: '',
        });
      }, 5000);
    },
    onError: (err) => {
      console.error('Form submission error:', err);
      setError(err.message || 'Failed to submit form. Please try again.');
    },
  });

  const categories = [
    { value: 'government', zh: '政府事务', en: 'Government Affairs', tc: '政府事務' },
    { value: 'talent', zh: '人才外包', en: 'Talent Outsourcing', tc: '人才外包' },
    { value: 'ai', zh: 'AI 匹配', en: 'AI Matching', tc: 'AI 匹配' },
    { value: 'other', zh: '其他', en: 'Other', tc: '其他' },
  ];

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
    setError(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.name.trim()) {
      setError(t('contact.name') + ' ' + 'is required');
      return;
    }

    if (formData.email && !formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return;
    }

    // Submit form via tRPC
    await submitMutation.mutateAsync({
      name: formData.name,
      position: formData.position || undefined,
      company: formData.company || undefined,
      category: formData.category,
      challenge: formData.challenge || undefined,
      email: formData.email || undefined,
      phone: formData.phone || undefined,
      language: language as 'en' | 'zh' | 'tc',
    });
  };

  if (!isVisible) return null;

  return (
    <section 
      id="contact-form"
      className="py-20 md:py-32"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      <div className="container mx-auto px-4">
        <div className="max-w-2xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 
              style={{
                color: '#0D1B2A',
                fontFamily: "'Playfair Display', serif",
                fontWeight: 800,
                fontSize: 'clamp(2rem, 5vw, 3.5rem)',
                letterSpacing: '-0.02em',
              }}
            >
              {t('contact.title')}
            </h2>
            <div className="flex justify-center mt-4">
              <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
            </div>
            <p 
              className="mt-6 text-lg"
              style={{
                color: '#2C3E50',
                fontFamily: "'Lato', sans-serif",
              }}
            >
              {t('contact.subtitle')}
            </p>
          </div>

          {/* Form */}
          {!submitted ? (
            <form 
              onSubmit={handleSubmit}
              className="space-y-6 rounded-lg p-8"
              style={{
                backgroundColor: '#FFFFFF',
                border: '1px solid #E5E5E5',
                boxShadow: '0 4px 16px rgba(0, 0, 0, 0.08)',
              }}
            >
              {/* Error Message */}
              {error && (
                <div 
                  className="p-4 rounded text-sm"
                  style={{
                    backgroundColor: '#FEE2E2',
                    color: '#DC2626',
                    fontFamily: "'Lato', sans-serif",
                  }}
                >
                  {error}
                </div>
              )}

              {/* Name and Position Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.name')}
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  />
                </div>
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.position')}
                  </label>
                  <input
                    type="text"
                    name="position"
                    value={formData.position}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  />
                </div>
              </div>

              {/* Company and Email Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.company')}
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  />
                </div>
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.email')}
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  />
                </div>
              </div>

              {/* Category and Phone Row */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.category')}
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  >
                    {categories.map(cat => (
                      <option key={cat.value} value={cat.value}>
                        {language === 'en' ? cat.en : language === 'tc' ? cat.tc : cat.zh}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label 
                    className="block text-sm font-semibold mb-2"
                    style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                  >
                    {t('contact.phone')}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded border transition-all duration-300"
                    style={{
                      borderColor: '#E5E5E5',
                      backgroundColor: '#FFFFFF',
                      color: '#0D1B2A',
                    }}
                    onFocus={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#D4AF37';
                      (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                    }}
                    onBlur={(e) => {
                      (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                      (e.target as HTMLElement).style.boxShadow = 'none';
                    }}
                  />
                </div>
              </div>

              {/* Challenge */}
              <div>
                <label 
                  className="block text-sm font-semibold mb-2"
                  style={{ color: '#0D1B2A', fontFamily: "'Lato', sans-serif" }}
                >
                  {t('contact.challenge')}
                </label>
                <textarea
                  name="challenge"
                  value={formData.challenge}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded border transition-all duration-300 resize-none"
                  style={{
                    borderColor: '#E5E5E5',
                    backgroundColor: '#FFFFFF',
                    color: '#0D1B2A',
                  }}
                  onFocus={(e) => {
                    (e.target as HTMLElement).style.borderColor = '#D4AF37';
                    (e.target as HTMLElement).style.boxShadow = '0 0 0 3px rgba(212, 175, 55, 0.1)';
                  }}
                  onBlur={(e) => {
                    (e.target as HTMLElement).style.borderColor = '#E5E5E5';
                    (e.target as HTMLElement).style.boxShadow = 'none';
                  }}
                />
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={submitMutation.isPending}
                className="w-full py-4 rounded text-lg font-semibold transition-all duration-300 flex items-center justify-center gap-2"
                style={{
                  backgroundColor: submitMutation.isPending ? '#999999' : '#D4AF37',
                  color: '#0D1B2A',
                  fontFamily: "'Lato', sans-serif",
                  cursor: submitMutation.isPending ? 'not-allowed' : 'pointer',
                }}
                onMouseEnter={(e) => {
                  if (!submitMutation.isPending) {
                    (e.currentTarget as HTMLElement).style.transform = 'translateY(-2px)';
                    (e.currentTarget as HTMLElement).style.boxShadow = '0 8px 24px rgba(212, 175, 55, 0.3)';
                  }
                }}
                onMouseLeave={(e) => {
                  (e.currentTarget as HTMLElement).style.transform = 'translateY(0)';
                  (e.currentTarget as HTMLElement).style.boxShadow = 'none';
                }}
              >
                {submitMutation.isPending && <Loader2 size={20} className="animate-spin" />}
                {t('contact.submit')}
              </button>
            </form>
          ) : (
            /* Success Message - Enhanced with better visual feedback */
            <div 
              className="rounded-lg p-12 text-center"
              style={{
                backgroundColor: '#ECFDF5',
                border: '3px solid #10B981',
                boxShadow: '0 10px 30px rgba(16, 185, 129, 0.2)',
              }}
            >
              <div className="mb-6 flex justify-center">
                <CheckCircle size={64} style={{ color: '#059669' }} />
              </div>
              <h3 
                className="text-3xl font-bold mb-4"
                style={{
                  color: '#059669',
                  fontFamily: "'Playfair Display', serif",
                }}
              >
                {t('contact.success')}
              </h3>
              <p 
                className="text-lg mb-4"
                style={{
                  color: '#047857',
                  fontFamily: "'Lato', sans-serif",
                }}
              >
                {t('contact.successMsg')}
              </p>
              <p 
                className="text-sm"
                style={{
                  color: '#10B981',
                  fontFamily: "'Lato', sans-serif",
                }}
              >
                {t('contact.successNote')}
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
