import { useLanguage } from '@/contexts/LanguageContext';

/**
 * About Us Component
 * Design Philosophy: Premium Business Elegance
 * - Elegant typography with Playfair Display
 * - Gold accent elements
 * - Responsive layout
 * - Trilingual support
 */

export default function AboutUs() {
  const { t } = useLanguage();

  return (
    <section 
      id="about"
      className="py-20 md:py-32"
      style={{ backgroundColor: '#FFFBF0' }}
    >
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto">
          {/* Section Header */}
          <div className="text-center mb-12">
            <h2 
              style={{
                color: '#0D1B2A',
                fontFamily: "'Playfair Display', serif",
                fontWeight: 800,
                fontSize: 'clamp(2rem, 5vw, 3.5rem)',
                letterSpacing: '-0.02em',
              }}
            >
              {t('about.title')}
            </h2>
            <div className="flex justify-center mt-4">
              <div style={{ width: '80px', height: '3px', backgroundColor: '#D4AF37' }} />
            </div>
          </div>

          {/* About Content */}
          <div 
            className="space-y-6 text-lg leading-relaxed"
            style={{
              color: '#2C3E50',
              fontFamily: "'Lato', sans-serif",
              lineHeight: '1.8',
            }}
          >
            <p>
              {t('about.para1')}
            </p>
            <p>
              {t('about.para2')}
            </p>
            <p>
              {t('about.para3')}
            </p>
          </div>

          {/* Key Values */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8">
            <div 
              className="p-6 rounded-lg text-center"
              style={{
                backgroundColor: '#0D1B2A',
                border: '2px solid #D4AF37',
                boxShadow: '0 4px 16px rgba(212, 175, 55, 0.15)',
              }}
            >
              <div 
                className="text-4xl font-bold mb-3"
                style={{ color: '#D4AF37' }}
              >
                {t('about.value1.icon')}
              </div>
              <h3 
                className="text-xl font-semibold mb-2"
                style={{ color: '#D4AF37', fontFamily: "'Playfair Display', serif" }}
              >
                {t('about.value1.title')}
              </h3>
              <p style={{ color: '#FFFBF0' }}>
                {t('about.value1.desc')}
              </p>
            </div>

            <div 
              className="p-6 rounded-lg text-center"
              style={{
                backgroundColor: '#0D1B2A',
                border: '2px solid #D4AF37',
                boxShadow: '0 4px 16px rgba(212, 175, 55, 0.15)',
              }}
            >
              <div 
                className="text-4xl font-bold mb-3"
                style={{ color: '#D4AF37' }}
              >
                {t('about.value2.icon')}
              </div>
              <h3 
                className="text-xl font-semibold mb-2"
                style={{ color: '#D4AF37', fontFamily: "'Playfair Display', serif" }}
              >
                {t('about.value2.title')}
              </h3>
              <p style={{ color: '#FFFBF0' }}>
                {t('about.value2.desc')}
              </p>
            </div>

            <div 
              className="p-6 rounded-lg text-center"
              style={{
                backgroundColor: '#0D1B2A',
                border: '2px solid #D4AF37',
                boxShadow: '0 4px 16px rgba(212, 175, 55, 0.15)',
              }}
            >
              <div 
                className="text-4xl font-bold mb-3"
                style={{ color: '#D4AF37' }}
              >
                {t('about.value3.icon')}
              </div>
              <h3 
                className="text-xl font-semibold mb-2"
                style={{ color: '#D4AF37', fontFamily: "'Playfair Display', serif" }}
              >
                {t('about.value3.title')}
              </h3>
              <p style={{ color: '#FFFBF0' }}>
                {t('about.value3.desc')}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
