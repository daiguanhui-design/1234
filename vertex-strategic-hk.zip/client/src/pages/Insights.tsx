import { useLanguage } from '@/contexts/LanguageContext';
import { useLocation } from 'wouter';
import { ArrowRight } from 'lucide-react';

interface Article {
  id: string;
  titleKey: string;
  dateKey: string;
  excerptKey: string;
}

const articles: Article[] = [
  {
    id: 'fractional-leadership-ai',
    titleKey: 'insights.article1.title',
    dateKey: 'insights.article1.date',
    excerptKey: 'insights.article1.excerpt',
  },
  {
    id: 'talent-capability-access',
    titleKey: 'insights.article2.title',
    dateKey: 'insights.article2.date',
    excerptKey: 'insights.article2.excerpt',
  },
  {
    id: 'government-enterprise-hub',
    titleKey: 'insights.article3.title',
    dateKey: 'insights.article3.date',
    excerptKey: 'insights.article3.excerpt',
  },
];

export default function Insights() {
  const { t } = useLanguage();
  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <div className="bg-gradient-to-b from-[#0A192F] to-[#0A192F] text-white py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">{t('insights.title')}</h1>
          <p className="text-xl text-gray-300">{t('insights.subtitle')}</p>
        </div>
      </div>

      {/* Articles Grid */}
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {articles.map((article) => (
            <div
              key={article.id}
              className="bg-white border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow duration-300"
            >
              {/* Article Card */}
              <div className="p-6 flex flex-col h-full">
                {/* Date */}
                <div className="text-sm text-[#D4AF37] font-semibold mb-3">
                  {t(article.dateKey)}
                </div>

                {/* Title */}
                <h2 className="text-2xl font-bold text-[#0A192F] mb-4 line-clamp-3">
                  {t(article.titleKey)}
                </h2>

                {/* Excerpt */}
                <p className="text-gray-600 mb-6 flex-grow line-clamp-4">
                  {t(article.excerptKey)}
                </p>

                {/* Read More Button */}
                <button
                  onClick={() => navigate(`/insights/${article.id}`)}
                  className="inline-flex items-center gap-2 text-[#D4AF37] font-semibold hover:gap-3 transition-all duration-300"
                >
                  {t('insights.readMore')}
                  <ArrowRight size={20} />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Coming Soon Notice */}
        <div className="mt-16 p-8 bg-gray-50 rounded-lg border border-gray-200">
          <h3 className="text-xl font-bold text-[#0A192F] mb-2">更多文章即将推出</h3>
          <p className="text-gray-600">
            我们正在准备更多关于跨境战略、AI驱动的创新和企业转型的深度洞察。敬请期待！
          </p>
        </div>
      </div>

      {/* CTA Section */}
      <div className="bg-[#0A192F] text-white py-12 px-4 mt-16">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-4">想要了解更多？</h2>
          <p className="text-gray-300 mb-8">
            联系我们的团队，讨论如何通过 Fractional Leadership 和 AI 驱动的解决方案加速您的业务增长。
          </p>
          <a
            href="mailto:contact@ivchk.com"
            className="inline-block bg-[#D4AF37] text-[#0A192F] px-8 py-3 rounded font-bold hover:bg-yellow-400 transition-colors duration-300"
          >
            联系我们
          </a>
        </div>
      </div>
    </div>
  );
}
