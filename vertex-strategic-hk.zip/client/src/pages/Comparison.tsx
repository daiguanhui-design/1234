import { useLocation } from 'wouter';
import Navigation from '@/components/Navigation';
import ComparisonTable from '@/components/ComparisonTable';
import Footer from '@/components/Footer';
import { useLanguage } from '@/contexts/LanguageContext';
import { ChevronLeft } from 'lucide-react';

export default function Comparison() {
  const [, setLocation] = useLocation();
  const { t } = useLanguage();

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFFBF0' }}>
      <Navigation />
      
      {/* Header Section */}
      <section 
        className="py-16 px-4"
        style={{ backgroundColor: '#0D1B2A', color: '#FFFBF0' }}
      >
        <div className="container mx-auto">
          <button
            onClick={() => setLocation('/')}
            className="flex items-center gap-2 mb-8 text-sm font-medium transition-all duration-300 hover:opacity-80"
            style={{ color: '#D4AF37' }}
          >
            <ChevronLeft size={20} />
            {t('comparison.backToHome')}
          </button>
          
          <h1 
            className="text-4xl md:text-5xl font-bold mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {t('comparison.pageTitle')}
          </h1>
          
          <p 
            className="text-lg opacity-90 max-w-2xl"
            style={{ fontFamily: "'Lato', sans-serif" }}
          >
            {t('comparison.pageSubtitle')}
          </p>
        </div>
      </section>

      {/* Comparison Table Section */}
      <section className="py-16 px-4">
        <div className="container mx-auto">
          <ComparisonTable />
        </div>
      </section>

      <Footer />
    </div>
  );
}
