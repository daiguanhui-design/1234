import { useState } from 'react';
import { useAuth } from '@/_core/hooks/useAuth';
import Navigation from '@/components/Navigation';
import HeroSection from '@/components/HeroSection';
import ServicePillars from '@/components/ServicePillars';
import ExpertMatrixNew from '@/components/ExpertMatrixNew';
import PartnerEcosystem from '@/components/PartnerEcosystem';
import ContactForm from '@/components/ContactForm';
import Footer from '@/components/Footer';
import AboutUs from '@/components/AboutUs';
import ComparisonTable from '@/components/ComparisonTable';

/**
 * Home Page - Premium Business Elegance Design
 * Main landing page for InsightfulVision Consulting Limited
 */

export default function Home() {
  // The userAuth hooks provides authentication state
  // To implement login/logout functionality, simply call logout() or redirect to getLoginUrl()
  let { user, loading, error, isAuthenticated, logout } = useAuth();

  const [showContactForm, setShowContactForm] = useState(false);

  const handleConsultClick = () => {
    setShowContactForm(true);
    setTimeout(() => {
      document.querySelector('#contact-form')?.scrollIntoView({ behavior: 'smooth' });
    }, 100);
  };

  const handleExpertsClick = () => {
    document.querySelector('#experts')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen" style={{ backgroundColor: '#FFFBF0' }}>
      <Navigation onContactClick={handleConsultClick} />
      <HeroSection onConsultClick={handleConsultClick} onExpertsClick={handleExpertsClick} />
      <AboutUs />
      <ServicePillars />
      <ExpertMatrixNew />
      <ComparisonTable />
      <PartnerEcosystem />
      <ContactForm isVisible={showContactForm} />
      <Footer />
    </div>
  );
}
